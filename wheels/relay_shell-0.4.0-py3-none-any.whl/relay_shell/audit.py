"""Append-only, output-hashed audit trail.

One JSON object per line. The output *body* is never written - only its
SHA-256 and byte length - so the log is safe to ship off-host. Arguments are
redacted by the caller (see :mod:`relay_shell.redaction`) before they arrive here.

The handler is rotation-safe (:class:`logging.handlers.WatchedFileHandler`):
make ``audit.jsonl`` append-only on disk with ``chattr +a`` and rotate it with
the bundled logrotate config; the handler reopens the file after rotation.

Audit failures must never break a tool call: if the sink cannot be opened the
logger degrades to stderr (or silence) and records ``degraded=True``.
"""

from __future__ import annotations

import contextlib
import gzip
import json
import logging
import os
import sys
import threading
from collections import deque
from dataclasses import dataclass
from logging.handlers import WatchedFileHandler
from pathlib import Path
from typing import Any

from .util import now_iso, sha256_hex

__all__ = ["AuditLogger", "ChainResult", "verify_chain"]


_U64_MASK = (1 << 64) - 1
_I64_SIGN_BIT = 1 << 63


def _format_jsonl(entry: dict[str, Any]) -> str:
    return json.dumps(entry, default=str, ensure_ascii=False)


def _syscall_arg_fields(args: tuple[int, ...]) -> tuple[list[int], list[str]]:
    """Return index-compatible signed values and lossless unsigned hex values."""
    unsigned = [arg & _U64_MASK for arg in args]
    signed = [value if value < _I64_SIGN_BIT else value - (_U64_MASK + 1) for value in unsigned]
    exact_hex = [f"0x{value:016x}" for value in unsigned]
    return signed, exact_hex


def _stringify(value: Any) -> str:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return str(value)
    return json.dumps(value, default=str, ensure_ascii=False, separators=(",", ":"))


def _cef_escape(value: str) -> str:
    # CEF extension escaping for separators and line breaks.
    return (
        value.replace("\\", "\\\\")
        .replace("=", "\\=")
        .replace("|", "\\|")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
    )


def _cef_header_escape(value: str) -> str:
    # CEF *header* fields escape backslash and the `|` separator only (`=` is
    # an extension-only escape). The header fields are constants today, so this
    # is defensive (FMT-2): a future dynamic field cannot break the header or
    # split a record.
    return value.replace("\\", "\\\\").replace("|", "\\|").replace("\n", "\\n").replace("\r", "\\r")


def _leef_escape(value: str) -> str:
    # LEEF extension escaping with tab-separated key-value fields.
    return (
        value.replace("\\", "\\\\")
        .replace("=", "\\=")
        .replace("\t", "\\t")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
    )


def _format_cef(entry: dict[str, Any]) -> str:
    # Header fields: vendor|product|version|signatureID|name|severity (FMT-2).
    header = "|".join(
        _cef_header_escape(f)
        for f in ("relay-shell", "relay-shell", "1.0", "audit", "tool-call", "5")
    )
    ext = " ".join(f"{k}={_cef_escape(_stringify(v))}" for k, v in sorted(entry.items()))
    return f"CEF:0|{header}|{ext}"


def _format_leef(entry: dict[str, Any]) -> str:
    # LEEF 2.0's 6th header field declares the extension delimiter. A tab is
    # declared in the spec's hex form `x09` so a strict parser does not treat
    # `audit` as the delimiter (FMT-1).
    ext = "\t".join(f"{k}={_leef_escape(_stringify(v))}" for k, v in sorted(entry.items()))
    return f"LEEF:2.0|relay-shell|relay-shell|1.0|audit|x09|{ext}"


_FORMATTERS = {"jsonl": _format_jsonl, "cef": _format_cef, "leef": _format_leef}


# --- Tamper-evident hash chain (opt-in; see docs/adr/0007-audit-hash-chain.md) ---

# Anchor for seq 0. A rotated file inherits its anchor from the last record of
# the prior file (that record's `chain` becomes the next record's `prev`).
_CHAIN_GENESIS = "0" * 64


def _tail_path(path: Path, lines: int) -> str:
    """Return the last non-empty lines from a plain or gzip-compressed file."""
    if lines <= 0:
        return ""

    if path.suffix == ".gz":
        compressed_records: deque[str] = deque(maxlen=lines)
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                if raw.strip():
                    compressed_records.append(raw.rstrip("\r\n"))
        return "\n".join(compressed_records)

    with path.open("rb") as fh:
        fh.seek(0, os.SEEK_END)
        size = fh.tell()
        if size == 0:
            return ""

        chunk_size = 8192
        data = b""
        offset = size
        while offset > 0 and data.count(b"\n") <= lines:
            read = min(chunk_size, offset)
            offset -= read
            fh.seek(offset)
            data = fh.read(read) + data

    text = data.decode("utf-8", errors="replace")
    text_records = [line for line in text.split("\n") if line.strip()]
    return "\n".join(text_records[-lines:])


def _latest_rotated_path(target: Path) -> Path | None:
    """Find the newest sibling produced by dateext or numeric log rotation."""
    candidates: list[tuple[int, str, Path]] = []
    for path in target.parent.iterdir():
        if path == target or not path.is_file():
            continue
        suffix = path.name[len(target.name) :]
        if suffix.endswith(".gz"):
            suffix = suffix[:-3]
        if not (len(suffix) > 1 and suffix[0] in {"-", "."} and suffix[1:].isdigit()):
            continue
        candidates.append((path.stat().st_mtime_ns, path.name, path))
    latest = max(candidates, default=None)
    return latest[2] if latest is not None else None


def _chain_value(prev: str, entry_without_chain: dict[str, Any]) -> str:
    """SHA-256 over the previous chain hash + the canonical record body.

    The body is serialized with sorted keys and compact separators so the
    value is independent of dict insertion order and of the on-disk
    formatter: a verifier reconstructs the exact same input from a parsed
    JSONL line by dropping the record's own ``chain`` field. Any edit,
    insertion, interior deletion, or reordering of records breaks the
    recomputation or the ``prev`` linkage downstream. (Head/tail truncation
    of the file is a separate concern handled by the genesis anchor and the
    off-host copy — see :func:`verify_chain` and ADR 0007.)
    """
    canonical = json.dumps(
        entry_without_chain,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
        ensure_ascii=False,
    )
    return sha256_hex(prev + canonical)


def _is_chained(rec: Any) -> bool:
    """True if ``rec`` is a JSONL record carrying the three chain fields."""
    return (
        isinstance(rec, dict)
        and isinstance(rec.get("seq"), int)
        and isinstance(rec.get("prev"), str)
        and isinstance(rec.get("chain"), str)
    )


@dataclass(frozen=True)
class ChainResult:
    """Outcome of :func:`verify_chain` over one on-disk audit file."""

    ok: bool
    records: int  # chained records verified
    start_seq: int | None  # seq of the first chained record (anchor)
    start_prev: str | None  # the first record's `prev` (cross-file anchor)
    broken_at: int | None  # 1-based line number of the first break, else None
    reason: str
    # True iff the verified region begins at genesis (seq 0, prev == genesis).
    # This is the head-truncation signal; tail-truncation is undetectable from
    # the file alone and is caught only by the off-host seam comparison (see
    # verify_chain and ADR 0007).
    anchored: bool = False
    # Whether the audit file existed and was readable. `verify_chain` treats a
    # missing file as "no break found" (ok=True, records=0); the CLI fails
    # closed and rejects a missing or empty log.
    present: bool = True


def verify_chain(path: str) -> ChainResult:
    """Verify the hash chain of an audit ``jsonl`` file.

    Walks the file once, skipping any leading legacy (unchained) records,
    and verifies that from the first chained record to EOF the chain is
    internally consistent: each ``seq`` increments by one, each ``prev``
    equals the previous record's ``chain``, and each record's body
    recomputes to its stated ``chain``.

    What this proves, and what it does NOT (a keyless single-file chain):
    it proves the records from the first surviving one to the last are
    unaltered, contiguous, and correctly ordered. It does *not* prove the
    first surviving record is the true beginning (head-truncation) or the
    last is the true end (tail-truncation) — both leave a shorter but
    internally valid sub-chain. ``ChainResult.anchored`` is the
    head-truncation signal: a log built from genesis but no longer starting
    at seq 0 / genesis ``prev`` has had leading records removed (or is a
    mid-stream rotation segment). Tail-truncation is undetectable from the
    file alone; catch it with the cross-rotation seam against the off-host
    copy (the prior file's last ``chain`` == this file's first ``prev``).
    Never raises.
    """
    try:
        p = Path(path).expanduser()
        if not p.is_file():
            return ChainResult(
                True, 0, None, None, None, f"audit file not found: {path}", present=False
            )
    except Exception as exc:  # noqa: BLE001 - never raise from a verifier
        return ChainResult(
            False, 0, None, None, None, f"cannot access audit file: {exc}", present=False
        )

    records = 0
    started = False
    start_seq: int | None = None
    start_prev: str | None = None
    expected_seq = 0
    expected_prev = _CHAIN_GENESIS
    try:
        with p.open("r", encoding="utf-8", errors="replace") as fh:
            for lineno, raw in enumerate(fh, start=1):
                line = raw.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    if started:
                        return ChainResult(
                            False,
                            records,
                            start_seq,
                            start_prev,
                            lineno,
                            f"line {lineno}: invalid JSON inside the chained region",
                        )
                    continue
                if not _is_chained(rec):
                    if started:
                        return ChainResult(
                            False,
                            records,
                            start_seq,
                            start_prev,
                            lineno,
                            f"line {lineno}: record missing chain fields inside the chained region",
                        )
                    continue  # leading legacy / unchained record
                if not started:
                    started = True
                    start_seq = expected_seq = rec["seq"]
                    start_prev = expected_prev = rec["prev"]
                    if rec["seq"] == 0 and rec["prev"] != _CHAIN_GENESIS:
                        return ChainResult(
                            False,
                            records,
                            start_seq,
                            start_prev,
                            lineno,
                            f"line {lineno}: seq 0 must anchor to genesis",
                        )
                if rec["seq"] != expected_seq:
                    return ChainResult(
                        False,
                        records,
                        start_seq,
                        start_prev,
                        lineno,
                        f"line {lineno}: expected seq {expected_seq}, found {rec['seq']}",
                    )
                if rec["prev"] != expected_prev:
                    return ChainResult(
                        False,
                        records,
                        start_seq,
                        start_prev,
                        lineno,
                        f"line {lineno}: prev does not match the previous record's chain",
                    )
                body = {k: v for k, v in rec.items() if k != "chain"}
                if _chain_value(rec["prev"], body) != rec["chain"]:
                    return ChainResult(
                        False,
                        records,
                        start_seq,
                        start_prev,
                        lineno,
                        f"line {lineno}: record body does not match its chain hash (tampered)",
                    )
                records += 1
                expected_prev = rec["chain"]
                expected_seq += 1
    except OSError as exc:
        return ChainResult(False, records, start_seq, start_prev, None, f"read error: {exc}")

    if not started:
        return ChainResult(
            True, 0, None, None, None, "no chained records found (empty or unchained log)"
        )
    anchored = start_seq == 0 and start_prev == _CHAIN_GENESIS
    if anchored:
        reason = f"chain intact and genesis-anchored: {records} record(s) from seq 0"
    else:
        # Head-truncation or a mid-stream rotation segment; one file cannot
        # tell which. The fail-closed CLI rejects this unless the operator
        # asserts a rotation segment with `--segment`.
        reason = (
            f"chain internally consistent: {records} record(s) from seq {start_seq}, "
            f"but NOT genesis-anchored (leading records removed, or a mid-stream "
            f"rotation segment — verify the seam against the prior file)"
        )
    return ChainResult(True, records, start_seq, start_prev, None, reason, anchored=anchored)


class _AuditFileHandler(WatchedFileHandler):
    owner: Any = None

    def handleError(self, record: logging.LogRecord) -> None:
        if self.owner is not None:
            self.owner.degraded = True
            self.owner.degraded_reason = "audit write failed at runtime"
        super().handleError(record)


class AuditLogger:
    """Writes structured audit records. Construction never raises."""

    def __init__(
        self,
        path: str,
        also_stderr: bool = False,
        fmt: str = "jsonl",
        chain: bool = False,
    ) -> None:
        self.path = path
        self.degraded = False
        self.degraded_reason = ""
        self.format = fmt
        # `_chain_lock` keeps seq monotonic and prev == previous chain when
        # another thread records (e.g. the seccomp-notify supervisor, ADR 0006).
        # Never taken when `chain` is off.
        self.chain = chain
        self._chain_lock = threading.Lock()
        # Makes "first degraded reason wins" atomic across supervisor threads.
        self._degrade_lock = threading.Lock()
        self._seq = 0
        self._prev = _CHAIN_GENESIS
        self._log = logging.getLogger("relay_shell.audit")
        self._log.setLevel(logging.INFO)
        self._log.propagate = False
        for handler in list(self._log.handlers):
            # Close before removing: re-initializing on the process-global
            # logger (--check-config, tests) otherwise leaks one fd per
            # construction until GC.
            with contextlib.suppress(Exception):
                handler.close()
            self._log.removeHandler(handler)

        sink: logging.Handler
        try:
            target = Path(path).expanduser()
            target.parent.mkdir(parents=True, exist_ok=True)
            # O_APPEND keeps this compatible with `chattr +a` files.
            fd = os.open(str(target), os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
            os.close(fd)
            # Defensive for existing files that might already be too permissive.
            with contextlib.suppress(OSError):
                target.chmod(0o600)
            # OBS-1: a non-regular sink (`/dev/null`, device, FIFO) accepts
            # writes but stores nothing durable. Flag it degraded so the
            # `relay_shell_audit_degraded` gauge and `server_info.audit` show
            # it; the sink itself is left as configured.
            if not target.is_file():
                self.degraded = True
                self.degraded_reason = (
                    f"audit path is not a regular file (records not durably stored): {path}"
                )
            sink = _AuditFileHandler(str(target), encoding="utf-8", errors="backslashreplace")
            sink.owner = self
        except OSError as exc:  # unwritable path -> degrade, never crash
            self.degraded = True
            self.degraded_reason = str(exc)
            sink = logging.StreamHandler(sys.stderr)
        sink.setFormatter(logging.Formatter("%(message)s"))
        self._log.addHandler(sink)

        if also_stderr and not self.degraded:
            echo = logging.StreamHandler(sys.stderr)
            echo.setFormatter(logging.Formatter("AUDIT %(message)s"))
            self._log.addHandler(echo)

        if self.chain:
            self._resume_chain()

    def _resume_chain(self) -> None:
        """Continue an existing chain across restarts and log rotation.

        Reads the last on-disk record and resumes from its ``seq`` + ``chain``
        so a restart does not reset the chain to genesis mid-stream. If the
        active log is empty, as it is after logrotate creates a fresh file,
        the newest rotated sibling supplies the anchor. A non-empty malformed
        active tail never falls back to older history: it starts a visible
        genesis seam rather than masking possible corruption.

        Best-effort: a missing / unchained / unparseable tail leaves the chain
        at genesis (seq 0). That produces a *visible seam* a verifier reports,
        never a silent gap. Construction of the audit logger must not fail.
        """
        with contextlib.suppress(Exception):
            target = Path(self.path).expanduser()
            last = _tail_path(target, 1).strip()
            if not last and target.stat().st_size == 0:
                rotated = _latest_rotated_path(target)
                if rotated is not None:
                    last = _tail_path(rotated, 1).strip()
            if not last:
                return
            rec = json.loads(last)
            if _is_chained(rec):
                self._seq = int(rec["seq"]) + 1
                self._prev = str(rec["chain"])

    def record(
        self,
        *,
        tool: str,
        args: dict[str, Any],
        output: str,
        exit_code: int | None,
        tier: int,
        request_id: str = "",
        client_id: str = "",
        denied: bool = False,
        action: str = "",
    ) -> None:
        """Append one audit line. Best-effort; swallows its own errors.

        ``action`` is an optional, additive marker for a control-plane phase of
        a call (the Tier-3 confirmation broker sets ``confirm_plan`` on the
        challenge record and ``confirm_execute`` on the executed record; ADR
        0009). Like ``request_id``/``client_id`` it is written only when
        non-empty, so a default call (and the whole default-off configuration)
        produces a byte-identical record.
        """
        entry: dict[str, Any] = {
            "ts": now_iso(),
            "tool": tool,
            "tier": tier,
            "denied": denied,
            "args": args,
            "output_sha256": sha256_hex(output),
            "output_len": len(output.encode("utf-8", "replace")),
            "exit_code": exit_code,
        }
        if request_id:
            entry["request_id"] = request_id
        if client_id:
            entry["client_id"] = client_id
        if action:
            entry["action"] = action
        self._emit(entry)

    def mark_degraded(self, reason: str) -> None:
        """Flag the sink degraded after a runtime failure elsewhere (ADR 0006).

        Used for the gap the seccomp-notify supervisor reports when it fails open
        (the child ran unfiltered, so its syscalls are missing from the trail).
        Called from supervisor threads, so the check and both stores are one
        critical section. The first reason is kept, so a later gap never hides
        an earlier, more severe one such as a failed write.
        """
        with self._degrade_lock:
            if not self.degraded:
                self.degraded_reason = reason
                self.degraded = True

    def record_syscall(
        self,
        *,
        pid: int,
        syscall: str,
        nr: int,
        args: tuple[int, ...],
        request_id: str = "",
    ) -> None:
        """Append one syscall-notification observation (ADR 0006).

        A *passive* tier-0 event emitted by the seccomp-notify supervisor for
        a single allowed-to-continue syscall in a spawned child. It is an
        ADDITIONAL line in the same stream, never a replacement for the
        per-call record: it carries no output hash (there is no output) and
        records only scalar register arguments — never a dereferenced user
        buffer. The numeric array uses signed 64-bit two's-complement values
        so common SIEM integer mappings can ingest every kernel ``__u64``;
        the aligned hexadecimal array preserves the exact unsigned bits.
        Off-host parsers key on ``tool`` to route it.
        """
        signed_args, exact_hex_args = _syscall_arg_fields(args)
        entry: dict[str, Any] = {
            "ts": now_iso(),
            "tool": "syscall_notify",
            "tier": 0,
            "pid": pid,
            "syscall": syscall,
            "nr": nr,
            "syscall_args": signed_args,
            "syscall_args_hex": exact_hex_args,
        }
        if request_id:
            entry["request_id"] = request_id
        self._emit(entry)

    def record_syscall_overflow(self, *, pid: int, cap: int, request_id: str = "") -> None:
        """Append one ``syscall_notify_overflow`` marker (ADR 0006).

        Emitted once per tool call when the child crosses the per-call event
        cap. Beyond the cap the supervisor keeps answering CONTINUE (the child
        is never blocked) but stops emitting per-syscall events; this single
        line records that the cap was hit.
        """
        entry: dict[str, Any] = {
            "ts": now_iso(),
            "tool": "syscall_notify_overflow",
            "tier": 0,
            "pid": pid,
            "cap": cap,
        }
        if request_id:
            entry["request_id"] = request_id
        self._emit(entry)

    def _emit(self, entry: dict[str, Any]) -> None:
        """Format + append one record, advancing the hash chain under lock.

        Shared by :meth:`record` and the syscall-event recorders. Audit must
        never break a caller, so all failure is swallowed. When chaining is on,
        the anchor advances once the line has been handed to the logging handler.
        ``logging`` swallows I/O errors from the handler itself (it reports them to
        stderr and returns), so a write that failed on disk still advances the anchor;
        the missing record then shows up as a ``seq`` gap that ``--verify-audit``
        reports, which is the intended tamper-evident outcome. One relay process
        owns one chained log: two writers would each keep their own ``seq`` / ``prev``
        and fork the chain. ``_chain_lock`` serializes the seccomp-notify supervisor
        thread against the tool-call path so seq/prev stay monotonic across both
        writers inside one process.
        """
        with contextlib.suppress(Exception):
            formatter = _FORMATTERS.get(self.format, _format_jsonl)
            if self.chain:
                with self._chain_lock:
                    entry["seq"] = self._seq
                    entry["prev"] = self._prev
                    chain = _chain_value(self._prev, entry)
                    entry["chain"] = chain
                    self._log.info(formatter(entry))
                    self._seq += 1
                    self._prev = chain
            else:
                self._log.info(formatter(entry))

    def tail(self, lines: int) -> str:
        """Return the last ``lines`` audit records as on-disk text lines.

        Records are returned in their original on-disk order (oldest first).
        The empty string is returned if the audit file does not exist, is
        empty, or cannot be read - this method must never raise; it is
        consumed by a read-only diagnostic tool and a failure here should
        not break the caller.

        Reading is opened on a fresh fd; the writer's append-only fd is
        untouched so this is safe to call concurrently with normal tool
        execution. ``WatchedFileHandler`` line-buffers each emit, so any
        record returned here is structurally complete.

        Implementation reads backward from end-of-file in 8 KiB chunks
        and stops as soon as it has ``lines + 1`` newlines (the +1
        catches a partial leading line). Worst-case memory is bounded
        by ``lines * record_size + chunk_size``, not by file size, so
        the bounded-execution invariant holds even when the audit log
        has not rotated in a long time.
        """
        if lines <= 0:
            return ""
        # Broad except: any failure (odd OSError, ValueError from an embedded
        # NUL, decode error) must collapse to "" for the diagnostic tool.
        try:
            return _tail_path(Path(self.path).expanduser(), lines)
        except Exception:  # noqa: BLE001 - contract is "never raise"
            return ""
