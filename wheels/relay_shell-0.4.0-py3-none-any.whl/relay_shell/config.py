"""Typed, environment-driven configuration.

All settings are read from ``RELAY_SHELL_*`` environment variables (and an optional
``.env``). Invalid values fail fast at startup rather than mid-run.
"""

from __future__ import annotations

import difflib
import ipaddress
import logging
import os
import re
from collections.abc import Mapping
from functools import lru_cache
from pathlib import Path

from pydantic import Field, ValidationInfo, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

__all__ = ["Settings", "get_settings", "unknown_settings_names"]

_log = logging.getLogger("relay_shell.config")

_TRANSPORTS = {"stdio", "http"}
_POLICY_MODES = {"open", "guarded", "readonly"}
_KNOWN_HOSTS = {"strict", "accept-new", "ignore"}
_AUDIT_FORMATS = {"jsonl", "cef", "leef"}
_AUDIT_SESSION_INPUT = {"redacted", "hash"}


def _is_loopback(host: str) -> bool:
    """True for ``localhost`` and loopback IP literals. Any other name is not
    assumed to be loopback: a resolver can point it anywhere."""
    h = host.strip().strip("[]").lower()
    if h == "localhost":
        return True
    try:
        return ipaddress.ip_address(h).is_loopback
    except ValueError:
        return False


class Settings(BaseSettings):
    """Effective server configuration. Immutable after load."""

    model_config = SettingsConfigDict(
        env_prefix="RELAY_SHELL_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        frozen=True,
    )

    # Transport
    transport: str = "stdio"
    http_host: str = "127.0.0.1"
    http_port: int = Field(default=8080, ge=1, le=65535)
    # Serving HTTP on anything but loopback with no authentication hands shell and SSH
    # access to every host that can reach the port, and /metrics is outside OAuth by
    # design. That combination is refused at startup unless the operator says it is
    # intended (for example an authenticating proxy is the only way to the port).
    allow_unauth_network: bool = False

    # Limits. Every bound has an explicit `le=` cap (CFG-1) so an absurd value
    # (e.g. a 1 TB output cap) is rejected instead of becoming a memory/DoS
    # footgun. The caps are far above any real config.
    max_output: int = Field(default=65536, ge=1024, le=16_777_216)
    max_output_hard: int = Field(default=1_048_576, ge=4096, le=134_217_728)
    # Ceiling, in characters, on the text a single call may put in front of the
    # policy layer (command, stdin, script body and env overlay together). The tier
    # classifier and deny regex run synchronously on the event loop at about 0.5 s
    # per MiB, so unbounded input would stall every session. A call over the ceiling
    # is refused (audited as denied) rather than scanned partially, which would let
    # padding hide a command. Raise it for deployments that pipe multi-MiB payloads.
    max_input: int = Field(default=2_097_152, ge=1024, le=134_217_728)
    default_timeout: int = Field(default=60, ge=1, le=86_400)
    max_timeout: int = Field(default=900, ge=1, le=86_400)
    max_sessions: int = Field(default=64, ge=1, le=1024)
    max_forwards: int = Field(default=64, ge=1, le=1024)
    # Hard ceiling on the live SSH connection cache (`SshPool._conns`). Without
    # it only opportunistic idle eviction (`ssh_idle_timeout`) bounds the cache,
    # so varying target or per-call auth (`user`/`port`/`key_path`) across many
    # reachable hosts can accumulate live connections between sweeps. A full
    # cache evicts the least-recently-used *unpinned* entry on a new connect;
    # connections in use (session, forward, in-flight run) are never evicted, so
    # the cap can be exceeded only by those.
    max_conns: int = Field(default=256, ge=1, le=4096)
    session_idle_timeout: int = Field(default=1800, ge=10, le=86_400)
    session_buffer_bytes: int = Field(default=262_144, ge=4096, le=16_777_216)

    # Policy
    policy_mode: str = "open"
    policy_deny: str = ""
    policy_allow: str = ""

    # Append a one-line `[NOTICE ...]` to the result of a call that ran as Tier 2/3 or with
    # SSH host-key verification off, and report the permissive settings in `server_info`
    # (ADR 0013). Informational only: it never blocks, and the audit record is unchanged.
    unsafe_notices: bool = True

    # Tier-3 confirmation broker (ADR 0009; opt-in, default off). When true, a
    # Tier-3 (IRREVERSIBLE) operation that passes the deny list and mode check
    # is not executed on first request: the runner returns a single-use,
    # TTL-bounded token and the caller must arm it via the `operation_confirm`
    # tool, then re-issue the exact same call. `confirm_ttl` bounds how long a
    # minted token stays valid before it must be re-planned.
    confirm_tier3: bool = False
    confirm_ttl: int = Field(default=120, ge=5, le=3600)

    # Audit
    audit_path: str = "/var/log/relay-shell/audit.jsonl"
    audit_stderr: bool = False
    audit_format: str = "jsonl"
    # How `session_send` input is recorded. `redacted` (default): the typed text
    # with pattern redaction, withheld entirely when the session is at a secret
    # prompt (sudo / ssh / passphrase). `hash`: only its length and SHA-256, for
    # deployments that must never write typed content to the log.
    audit_session_input: str = "redacted"
    # Tamper-evident audit: when true, each record carries a `seq`, the
    # previous record's chain hash (`prev`), and its own `chain` hash so a
    # verifier can detect insertion, deletion, reordering or edit of the
    # on-disk log (see docs/adr/0007-audit-hash-chain.md). Only the `jsonl`
    # format can resume the chain across restarts, so chaining requires it.
    audit_chain: bool = False
    # Write-ahead audit (opt-in, default off): append an `action="intent"` record
    # *before* a call's work runs, in addition to the completion record. Without
    # it a crash or SIGKILL mid-command leaves an executed command with no audit
    # trail. Default off keeps the one-record-per-call shape log consumers rely on.
    audit_intent: bool = False

    # Syscall-level audit channel (ADR 0006; opt-in, default off). When on,
    # locally-spawned children get a seccomp-bpf USER_NOTIF filter and the
    # supervisor appends one `syscall_notify` audit line per observed syscall
    # (execve, privilege/namespace/mount changes, write-opens). It never blocks
    # a syscall and activates only when the process holds CAP_SYS_ADMIN (so
    # set-uid/sudo behaviour is preserved); otherwise it no-ops.
    # `seccomp_notify_cap` bounds per-call event volume: beyond it one
    # `syscall_notify_overflow` line is written and emission stops (the child
    # still runs to completion).
    seccomp_notify: bool = False
    seccomp_notify_cap: int = Field(default=256, ge=1, le=65536)

    # SSH
    ssh_config: str = "~/.ssh/config"
    inventory: str = ""
    ssh_known_hosts: str = "accept-new"
    # When false, a per-call `known_hosts` weaker than `ssh_known_hosts` (for
    # example `ignore` against a `strict` default) is refused at connect time, so
    # a caller cannot downgrade host-key verification. A stronger per-call mode
    # and an operator-written inventory entry are always honoured. Default true
    # allows per-call overrides in either direction.
    ssh_allow_weaker_known_hosts: bool = True
    ssh_connect_timeout: int = Field(default=10, ge=1, le=120)
    ssh_keepalive: int = Field(default=30, ge=0, le=600)
    # Idle eviction for cached SSH connections. 0 disables the reaper. A
    # non-zero value drops a connection unused for that many seconds the next
    # time the pool is consulted; see SshPool._sweep_conns.
    ssh_idle_timeout: int = Field(default=1800, ge=0, le=86400)

    # OAuth 2.1 (HTTP transport only)
    auth_enabled: bool = False
    auth_issuer: str = "https://localhost:8080"
    auth_resource_url: str = ""  # Empty preserves the established issuer-based identifier.
    auth_state_dir: str = "/var/lib/relay-shell/oauth"
    auth_single_client: bool = True
    # Operator approval gate. Dynamic client registration is open to whoever can
    # reach /register and /authorize issues a code to any registered client with
    # no login step, so without this the first party to register obtains tokens
    # (shell execution as the service user). When true, a new client is *pending*
    # and /authorize refuses it until the operator approves it on the host
    # (`relay-shell --auth-approve CLIENT_ID`). Clients that exist at upgrade are
    # carried over as approved. Set false only where the edge itself authenticates
    # the caller.
    auth_require_approval: bool = True
    auth_access_ttl: int = Field(default=3600, ge=60)
    auth_refresh_ttl: int = Field(default=2_592_000, ge=300)
    auth_code_ttl: int = Field(default=300, ge=30)

    @field_validator("transport")
    @classmethod
    def _v_transport(cls, v: str) -> str:
        v = v.strip().lower()
        if v not in _TRANSPORTS:
            raise ValueError(f"transport must be one of {sorted(_TRANSPORTS)}")
        return v

    @field_validator("policy_mode")
    @classmethod
    def _v_policy(cls, v: str) -> str:
        v = v.strip().lower()
        if v not in _POLICY_MODES:
            raise ValueError(f"policy_mode must be one of {sorted(_POLICY_MODES)}")
        return v

    @field_validator("ssh_known_hosts")
    @classmethod
    def _v_known_hosts(cls, v: str) -> str:
        v = v.strip().lower()
        if v not in _KNOWN_HOSTS:
            raise ValueError(f"ssh_known_hosts must be one of {sorted(_KNOWN_HOSTS)}")
        return v

    @field_validator("policy_deny", "policy_allow")
    @classmethod
    def _v_policy_regex(cls, v: str, info: ValidationInfo) -> str:
        # Compile at load so a bad pattern is a clean "invalid configuration"
        # at startup, not a traceback from server assembly.
        try:
            re.compile(v)
        except re.error as exc:
            raise ValueError(f"{info.field_name} is not a valid regular expression: {exc}") from exc
        return v

    @field_validator("audit_session_input")
    @classmethod
    def _v_audit_session_input(cls, v: str) -> str:
        v = v.strip().lower()
        if v not in _AUDIT_SESSION_INPUT:
            raise ValueError(f"audit_session_input must be one of {sorted(_AUDIT_SESSION_INPUT)}")
        return v

    @field_validator("audit_format")
    @classmethod
    def _v_audit_format(cls, v: str) -> str:
        v = v.strip().lower()
        if v not in _AUDIT_FORMATS:
            raise ValueError(f"audit_format must be one of {sorted(_AUDIT_FORMATS)}")
        return v

    @model_validator(mode="after")
    def _v_http_exposure(self) -> Settings:
        if (
            self.transport == "http"
            and not self.auth_enabled
            and not self.allow_unauth_network
            and not _is_loopback(self.http_host)
        ):
            raise ValueError(
                f"refusing to serve HTTP on {self.http_host!r} without authentication: "
                "set RELAY_SHELL_AUTH_ENABLED=true, bind a loopback address, or set "
                "RELAY_SHELL_ALLOW_UNAUTH_NETWORK=true if an authenticating proxy is the "
                "only way to reach the port"
            )
        return self

    @model_validator(mode="after")
    def _v_chain_requires_jsonl(self) -> Settings:
        # The chain is defined over the on-disk `jsonl` record and resumed by
        # re-parsing the last line. CEF/LEEF are SIEM-ingest shapes where the
        # aggregator owns integrity, so refuse the combination at startup.
        if self.audit_chain and self.audit_format != "jsonl":
            raise ValueError("audit_chain=true requires audit_format=jsonl")
        return self


# Written by deploy/install-edge.sh into its own env file, so they can share a file with the
# server's settings without being Settings fields.
_FOREIGN_PREFIXES = ("RELAY_SHELL_EDGE_",)
_PREFIX = "RELAY_SHELL_"
# python-dotenv (which `Settings` uses) accepts `KEY=`, `export KEY=` and a single-quoted key
# (`'KEY'=`). A double-quoted key keeps its quotes in the name, so no setting can match it.
_DOTENV_KEY_RE = re.compile(r"""^\s*(?:export\s+)?(?:'(?P<sq>[^'=]+)'|(?P<bare>[^\s='"#]+))\s*=""")


def unknown_settings_names(
    environ: Mapping[str, str] | None = None, *, dotenv: Path | str = ".env"
) -> list[tuple[str, str | None]]:
    """``RELAY_SHELL_*`` names in the environment or ``.env`` that no setting reads.

    ``Settings`` ignores unknown names (``extra="ignore"``), so a typo such as
    ``RELAY_SHELL_POLICY_MOD`` would silently leave the default (``open``) in force.
    Returns ``(name, closest known name or None)``, sorted by name.
    """
    known = {f"{_PREFIX}{name.upper()}" for name in Settings.model_fields}
    names = set(os.environ if environ is None else environ)
    try:
        for line in Path(dotenv).read_text(encoding="utf-8").splitlines():
            if (m := _DOTENV_KEY_RE.match(line)) is not None:
                names.add(m.group("sq") or m.group("bare"))
    except OSError:
        pass
    unknown: dict[str, str | None] = {}
    for raw in names:
        name = raw.upper()
        if not name.startswith(_PREFIX) or name in known or name.startswith(_FOREIGN_PREFIXES):
            continue
        close = difflib.get_close_matches(name, known, n=1, cutoff=0.8)
        unknown[name] = close[0] if close else None
    return sorted(unknown.items())


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Process-wide cached settings instance."""
    settings = Settings()
    for name, close in unknown_settings_names():
        hint = f" (did you mean {close}?)" if close else ""
        _log.warning("ignoring unknown setting %s%s", name, hint)
    return settings
