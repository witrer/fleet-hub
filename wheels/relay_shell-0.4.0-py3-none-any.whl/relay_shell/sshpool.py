"""asyncssh-backed connection pool, SFTP, port forwarding, and a PTY adapter.

Connections are cached per ``user@host:port`` and reused. ``ssh_config`` is
handed to asyncssh so its full semantics (``ProxyJump``, per-host options) are
honoured; explicit arguments overlay it. ``known_hosts`` policy is explicit:
``strict`` (verify against the known_hosts file), ``ignore`` (no verification),
or ``accept-new`` (trust-on-first-use, persisted to the known_hosts file).
"""

from __future__ import annotations

import asyncio
import contextlib
import re
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import asyncssh

from .errors import ForwardError, RelayError, SessionError
from .inventory import HostSpec, Inventory
from .util import gen_id, truncate

__all__ = ["ForwardHandle", "SshPool", "SshProcessTransport"]

_SIG_NAMES = {2: "INT", 9: "KILL", 15: "TERM", 1: "HUP", 3: "QUIT"}
# Local listen address for L:/D: forwards. Never "" (asyncssh binds every interface for
# that), which would expose an unauthenticated forward/SOCKS proxy to the network.
_LOOPBACK = "127.0.0.1"
_KNOWN_HOSTS_MODES = frozenset({"strict", "accept-new", "ignore"})
# Verification strength, strongest first; used to refuse a per-call downgrade.
_KNOWN_HOSTS_WEAKNESS = {"strict": 0, "accept-new": 1, "ignore": 2}
# How long `run` waits for the channel to close after both output streams hit EOF.
_WAIT_CLOSED_TIMEOUT = 5.0
# ssh_spawn stdin back-pressure: bound the local write buffer and the wait for it to drain.
_MAX_PENDING_WRITE = 1 << 20
# Appended to every SSH timeout string. A timeout is not a result: the remote side may
# have finished, be finishing, or have done part of the work, so a mutation must be
# reconciled against remote state before a retry. It comes BEFORE any caller-controlled
# text (paths): the tool response is truncated, and long paths must not push it out.
_TIMEOUT_OUTCOME_UNKNOWN = (
    "outcome unknown: the remote side may still be running, may have completed, or may "
    "have applied part of the change; verify the remote state before retrying a mutation"
)
_DRAIN_TIMEOUT = 5.0

# Caller-supplied connection tokens. asyncssh substitutes the host and user into the
# operator's ``ProxyCommand`` (``%h``, ``%n``, ``%r``) and splits the result into argv, so
# whitespace, quotes or a leading ``-`` would add arguments (``-oProxyCommand=...``) to a
# local command; ``${VAR}`` in the value is expanded afterwards. The host is also written to
# known_hosts verbatim under ``accept-new``. A backslash is refused too: shlex treats it as an
# escape, so ``name\\`` would swallow the following space and merge two trusted arguments.
# Only a plain hostname, address or bracketed IPv6 literal passes; operator-written
# inventory/ssh_config aliases are trusted as written.
_HOST_TOKEN_RE = re.compile(r"[A-Za-z0-9_\[][A-Za-z0-9._\-:%\[\]]{0,254}")
_USER_TOKEN_RE = re.compile(r"[A-Za-z0-9_][A-Za-z0-9._\-]{0,127}")


def _check_ssh_tokens(*, host: str | None = None, user: str | None = None) -> None:
    """Raise ``RelayError`` unless the caller-supplied host/user are plain tokens."""
    if host is not None and not _HOST_TOKEN_RE.fullmatch(host):
        raise RelayError("invalid ssh host: expected a hostname or address (no spaces or quotes)")
    if user is not None and not _USER_TOKEN_RE.fullmatch(user):
        raise RelayError("invalid ssh user: expected a plain account name")


def _check_jump(jump: str) -> None:
    """Validate a caller-supplied ``[user@]host[:port][,...]`` jump chain hop by hop."""
    for hop in jump.split(","):
        user, sep, host = hop.rpartition("@")
        try:
            _check_ssh_tokens(host=host, user=user if sep else None)
        except RelayError:
            raise RelayError("invalid ssh jump: expected [user@]host[:port][,...]") from None


def _known_hosts_path() -> str:
    return str(Path("~/.ssh/known_hosts").expanduser())


def _conn_key(
    host: str,
    user: str | None,
    port: int | None,
    mode: str = "",
    key_path: str = "",
    jump: str = "",
) -> str:
    """Cache identity of a connection.

    Everything that decides *who we are talking to* or *who we are* must be in
    the key, otherwise a later call asking for stricter verification, another
    identity key or another jump host silently reuses a connection established
    under weaker or different terms. The connect timeout is excluded: it does
    not change the peer.
    """
    return f"{user or ''}@{host}:{port or 22}|{mode}|{key_path}|{jump}"


def _known_host_pattern(hostname: str, port: int | None) -> str:
    """OpenSSH known_hosts host field: ``host`` on port 22, else ``[host]:port``."""
    return hostname if not port or port == 22 else f"[{hostname}]:{port}"


def _host_is_known(path: str, hostname: str, port: int | None) -> bool:
    """True if ``path`` already holds a key (or CA) entry for ``hostname:port``.

    Fails closed: a known_hosts file that exists but cannot be read or parsed is
    reported as "known", so the caller verifies strictly against it and the
    connection is refused instead of silently trusting a new key.
    """
    kh = Path(path)
    if not kh.is_file():
        return False
    try:
        matched = asyncssh.read_known_hosts(str(kh)).match(hostname, "", port or 22)
        if matched[0] or matched[1]:
            return True
        # asyncssh silently skips an entry whose key field is corrupt, so a
        # damaged entry for this host would look "unknown". Treat a textual
        # host-field match as known too, so the strict path fails.
        pattern = _known_host_pattern(hostname, port)
        for line in kh.read_text(encoding="utf-8").splitlines():
            fields = line.split()
            if fields and not fields[0].startswith("#") and pattern in fields[0].split(","):
                return True
    except Exception:  # noqa: BLE001 - unreadable file: fail closed
        return True
    return False


def _append_known_host(hostname: str, algo: str, b64: str, port: int | None = None) -> None:
    """Synchronous known_hosts append (run off the event loop)."""
    kh = Path(_known_hosts_path())
    kh.parent.mkdir(parents=True, exist_ok=True)
    existing = kh.read_text(encoding="utf-8") if kh.is_file() else ""
    if b64 not in existing:
        # A final line without a newline would fuse with the new entry and corrupt both.
        sep = "\n" if existing and not existing.endswith("\n") else ""
        with kh.open("a", encoding="utf-8") as fh:
            fh.write(f"{sep}{_known_host_pattern(hostname, port)} {algo} {b64}\n")


class _OwnerCancelled(Exception):
    """The caller that owned a single-flight connect was cancelled (waiters retry)."""


@dataclass
class ForwardHandle:
    id: str
    kind: str
    spec: str
    listen_port: int
    target: str
    listener: Any
    # Cache entry this forward pins; released in close_forward so the idle reaper
    # cannot evict a connection while a forward still listens on it.
    entry: _ConnEntry | None = None


@dataclass
class _ConnEntry:
    """Cached SSH connection plus the monotonic time it was last used."""

    conn: Any
    last_used: float = field(default_factory=time.monotonic)
    # Live holders (ssh_spawn session, port forward, in-flight run/transfer). The
    # idle reaper never evicts an entry with pins > 0: a long-lived holder connects
    # once and drives channels directly, never refreshing last_used.
    pins: int = 0


class SshProcessTransport:
    """Adapts an asyncssh remote process to the session ``Transport``."""

    def __init__(
        self,
        proc: Any,
        *,
        pool: SshPool | None = None,
        entry: _ConnEntry | None = None,
    ) -> None:
        self._p = proc
        # Pool and cache entry backing this session's connection, pinned for the
        # session's lifetime and released in ``aclose`` (optional so tests can
        # build a bare transport around a fake process).
        self._pool = pool
        self._entry = entry

    async def write(self, data: bytes) -> None:
        stdin = self._p.stdin
        # A remote that stops reading must not let session_send grow the local
        # write buffer without bound (max_input only caps a single call).
        try:
            pending = stdin.get_write_buffer_size()
        except Exception:  # noqa: BLE001 - not every stdin double reports it
            pending = 0
        if pending > _MAX_PENDING_WRITE:
            raise SessionError(
                f"remote is not reading input ({pending} bytes pending); "
                "close the session or wait for it to drain"
            )
        with contextlib.suppress(Exception):
            stdin.write(data)
        # A drain timeout leaves the data queued (the cap above stops further growth);
        # a closed channel drops the input, as before.
        with contextlib.suppress(Exception):
            await asyncio.wait_for(stdin.drain(), _DRAIN_TIMEOUT)

    def resize(self, cols: int, rows: int) -> None:
        with contextlib.suppress(Exception):
            self._p.change_terminal_size(cols, rows)

    def signal(self, sig: int) -> None:
        name = _SIG_NAMES.get(sig, "TERM")
        try:
            self._p.send_signal(name)
        except Exception:  # noqa: BLE001 - any failure -> best-effort terminate
            with contextlib.suppress(Exception):
                self._p.terminate()

    @property
    def returncode(self) -> int | None:
        rc = self._p.returncode
        return int(rc) if isinstance(rc, int) else None

    async def read_loop(self, sink: object) -> None:
        assert callable(sink)
        while True:
            data = await self._p.stdout.read(65536)
            if not data:
                return
            sink(data if isinstance(data, bytes) else str(data).encode("utf-8", "replace"))

    async def aclose(self) -> None:
        try:
            with contextlib.suppress(Exception):
                self._p.terminate()
            with contextlib.suppress(Exception):
                await asyncio.wait_for(self._p.wait_closed(), 5)
        finally:
            # Even if terminate/wait_closed raised: a session that fails to close
            # cleanly must not pin its connection against the idle reaper forever.
            if self._pool is not None:
                await self._pool._unpin(self._entry)


@dataclass
class SshPool:
    settings: Any
    inventory: Inventory
    _conns: dict[str, _ConnEntry] = field(default_factory=dict)
    _forwards: dict[str, ForwardHandle] = field(default_factory=dict)
    # In-flight connect() futures keyed by connection key, so concurrent callers for
    # one target share a single ``asyncssh.connect``. Otherwise both would miss the
    # cache and dial, and the second would silently leak the first connection.
    _pending: dict[str, asyncio.Future[Any]] = field(default_factory=dict)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    async def _sweep_conns(self) -> None:
        """Evict closed or idle connections from the cache.

        Like ``SessionRegistry._sweep``, runs opportunistically on every
        ``connect()`` rather than as a background task. ``ssh_idle_timeout=0``
        disables idle eviction; closed connections are still purged so a
        re-connect does not return a dead handle.
        """
        timeout = float(getattr(self.settings, "ssh_idle_timeout", 0) or 0)
        now = time.monotonic()
        doomed: list[Any] = []
        async with self._lock:
            for key in list(self._conns):
                entry = self._conns[key]
                try:
                    closed = entry.conn.is_closed()
                except Exception:  # noqa: BLE001 - defensive: treat as closed
                    closed = True
                # Never idle-evict a pinned entry; a closed connection is dead
                # regardless of pins and is purged.
                idle_evict = timeout > 0 and entry.pins == 0 and now - entry.last_used > timeout
                if closed or idle_evict:
                    doomed.append(self._conns.pop(key).conn)
        for conn in doomed:
            with contextlib.suppress(Exception):
                conn.close()

    def _select_conn_evictions(self, need: int) -> list[str]:
        """Keys of the least-recently-used *unpinned* cached connections to drop
        so inserting ``need`` more entries keeps ``_conns`` within ``max_conns``.

        Caller holds ``_lock``. Idle eviction (``ssh_idle_timeout``) is
        opportunistic and unbounded in count, so this adds a hard ceiling beneath
        ``max_sessions`` / ``max_forwards``. Pinned entries are never candidates:
        if every entry is pinned the cap is transiently exceeded rather than
        dropping a live connection.
        """
        cap = int(getattr(self.settings, "max_conns", 0) or 0)
        if cap <= 0:
            return []
        overflow = len(self._conns) + need - cap
        if overflow <= 0:
            return []
        evictable = sorted(
            (key for key, entry in self._conns.items() if entry.pins == 0),
            key=lambda key: self._conns[key].last_used,
        )
        return evictable[:overflow]

    async def _pin(self, conn: Any) -> _ConnEntry | None:
        """Pin the cached entry backing ``conn`` against idle eviction.

        Returns the entry (pass it to :meth:`_unpin`) or ``None`` if ``conn`` is
        not the cached connection, which the reaper cannot touch anyway.
        """
        async with self._lock:
            for entry in self._conns.values():
                if entry.conn is conn:
                    entry.pins += 1
                    entry.last_used = time.monotonic()
                    return entry
        return None

    async def _unpin(self, entry: _ConnEntry | None) -> None:
        """Release a pin taken by :meth:`_pin` (a no-op for ``None``)."""
        if entry is None:
            return
        async with self._lock:
            if entry.pins > 0:
                entry.pins -= 1
            entry.last_used = time.monotonic()

    @contextlib.asynccontextmanager
    async def _pinned(self, conn: Any) -> AsyncIterator[None]:
        """Pin ``conn``'s cache entry for a scoped operation (``run`` / SFTP
        transfer). Long-lived holders (sessions, forwards) pin explicitly and
        release on their own close.
        """
        entry = await self._pin(conn)
        try:
            yield
        finally:
            await self._unpin(entry)

    def _known_hosts_arg(self, mode: str, known: bool = False) -> object:
        """asyncssh ``known_hosts`` argument for ``mode``.

        ``accept-new`` is trust-on-first-use: a host with no entry connects
        unverified and is then recorded, but a host that already has an entry
        (``known=True``) is verified strictly, so a changed key is refused.
        """
        if mode not in _KNOWN_HOSTS_MODES:
            allowed = ", ".join(repr(v) for v in sorted(_KNOWN_HOSTS_MODES))
            raise ValueError(f"known_hosts must be one of {allowed}")
        if mode == "strict" or (mode == "accept-new" and known):
            return _known_hosts_path()
        return None

    async def _persist_host_key(self, conn: Any, hostname: str, port: int | None = None) -> None:
        try:
            key = conn.get_server_host_key()
            blob = key.export_public_key("openssh")
            text = blob.decode() if isinstance(blob, bytes) else str(blob)
            parts = text.split()
            if len(parts) < 2:
                return
            await asyncio.to_thread(_append_known_host, hostname, parts[0], parts[1], port)
        except Exception:  # noqa: BLE001 - host-key persistence is best-effort
            return

    async def connect(
        self,
        target: str,
        *,
        user: str = "",
        port: int = 0,
        key_path: str = "",
        known_hosts: str = "",
        jump: str = "",
        connect_timeout: int = 0,
    ) -> Any:
        spec: HostSpec = self.inventory.resolve(target)
        if not self.inventory.knows(target):
            # A passthrough target (``host`` or ``user@host``) is caller input.
            _check_ssh_tokens(
                host=spec.hostname, user=target.partition("@")[0] if "@" in target else None
            )
        if user:
            _check_ssh_tokens(user=user)
        if jump:
            _check_jump(jump)
        eff_user = user or spec.user or ""
        eff_port = port or spec.port or 0
        eff_key = key_path or spec.identity_file or ""
        eff_jump = jump or spec.jump or ""
        mode = (known_hosts or spec.known_hosts or self.settings.ssh_known_hosts).lower()
        # Only the caller-supplied value is policed: the server default and an
        # operator-written inventory entry are the operator's own choices.
        if (
            known_hosts
            and not self.settings.ssh_allow_weaker_known_hosts
            and _KNOWN_HOSTS_WEAKNESS.get(known_hosts.lower(), 0)
            > _KNOWN_HOSTS_WEAKNESS.get(self.settings.ssh_known_hosts, 0)
        ):
            raise RelayError(
                f"known_hosts={known_hosts.lower()} would weaken the server default "
                f"{self.settings.ssh_known_hosts!r}; refused "
                "(RELAY_SHELL_SSH_ALLOW_WEAKER_KNOWN_HOSTS=false)"
            )
        key = _conn_key(spec.hostname, eff_user or None, eff_port or None, mode, eff_key, eff_jump)

        await self._sweep_conns()
        # Cache lookup and single-flight claim happen together under the lock. If
        # another coroutine is already connecting to this key we await its future;
        # otherwise we claim the slot and connect outside the lock so other hosts
        # are not blocked.
        other_future: asyncio.Future[Any] | None = None
        own_future: asyncio.Future[Any] | None = None
        async with self._lock:
            entry = self._conns.get(key)
            if entry is not None and not entry.conn.is_closed():
                entry.last_used = time.monotonic()
                return entry.conn
            other_future = self._pending.get(key)
            if other_future is None:
                own_future = asyncio.get_running_loop().create_future()
                # With no concurrent waiter nobody retrieves a failed connect's
                # exception and asyncio logs "Future exception was never retrieved"
                # with a traceback. The owner re-raises the real error itself.
                own_future.add_done_callback(lambda f: f.cancelled() or f.exception())
                self._pending[key] = own_future
        if own_future is None:
            assert other_future is not None
            # Shield: task.cancel() cancels the awaited future, which unshielded
            # would be the shared one and poison every other waiter and the owner.
            try:
                return await asyncio.shield(other_future)
            except _OwnerCancelled:
                # The owner was cancelled, this waiter was not: retry (one waiter
                # becomes the new owner).
                return await self.connect(
                    target,
                    user=user,
                    port=port,
                    key_path=key_path,
                    known_hosts=known_hosts,
                    jump=jump,
                    connect_timeout=connect_timeout,
                )

        try:
            # Everything that can raise or be cancelled after the slot is claimed
            # stays inside this try, so the slot is always released and later
            # callers never wait on an unresolved future.
            #
            # accept-new verifies hosts it has seen before; only a first contact is
            # accepted unverified (and recorded below).
            known = (
                await asyncio.to_thread(
                    _host_is_known, _known_hosts_path(), spec.hostname, eff_port
                )
                if mode == "accept-new"
                else False
            )
            opts: dict[str, Any] = {
                "known_hosts": self._known_hosts_arg(mode, known),
                "connect_timeout": connect_timeout or self.settings.ssh_connect_timeout,
            }
            if self.settings.ssh_keepalive:
                opts["keepalive_interval"] = self.settings.ssh_keepalive
            if eff_user:
                opts["username"] = eff_user
            if eff_port:
                opts["port"] = eff_port
            if eff_key:
                opts["client_keys"] = [str(Path(eff_key).expanduser())]
            if eff_jump:
                opts["tunnel"] = eff_jump
            cfg = self.inventory.ssh_config_file
            if cfg:
                opts["config"] = [cfg]

            conn = await asyncssh.connect(spec.hostname, **opts)
            if mode == "accept-new" and not known:
                await self._persist_host_key(conn, spec.hostname, eff_port or None)
        except BaseException as exc:
            # Including CancelledError: clear the slot so a later caller can retry.
            # Pop only OUR slot: if close_all raced and a new caller installed a
            # fresh future, leave it. A cancelled owner must not cancel its waiters;
            # they get _OwnerCancelled and retry themselves.
            async with self._lock:
                if self._pending.get(key) is own_future:
                    self._pending.pop(key, None)
            if not own_future.done():
                own_future.set_exception(
                    _OwnerCancelled() if isinstance(exc, asyncio.CancelledError) else exc
                )
            raise
        # If the future was cancelled out from under us (only ``close_all`` does
        # this) discard the connection rather than cache it after the registry
        # was cleared, and surface the cancellation.
        if own_future.cancelled():
            with contextlib.suppress(Exception):
                conn.close()
            async with self._lock:
                if self._pending.get(key) is own_future:
                    self._pending.pop(key, None)
            raise asyncio.CancelledError("SshPool was closed while connecting")
        doomed: list[Any] = []
        async with self._lock:
            # Enforce max_conns before caching; evictees are closed outside the
            # lock. `need` is 0 when overwriting an existing key, 1 for a fresh one.
            need = 0 if key in self._conns else 1
            for evict_key in self._select_conn_evictions(need):
                doomed.append(self._conns.pop(evict_key).conn)
            self._conns[key] = _ConnEntry(conn=conn)
            if self._pending.get(key) is own_future:
                self._pending.pop(key, None)
        own_future.set_result(conn)
        for dead in doomed:
            with contextlib.suppress(Exception):
                dead.close()
        return conn

    async def run(
        self,
        target: str,
        command: str,
        *,
        timeout: int,
        connect_kwargs: dict[str, Any],
        max_output_bytes: int | None = None,
    ) -> tuple[str, int | None]:
        conn = await self.connect(target, **connect_kwargs)
        # Pin for the run's duration: last_used freezes at connect time, so a run
        # outliving the idle window would otherwise be evicted and closed mid-drain
        # by a concurrent connect()'s sweep. max_timeout (up to 86400) can exceed
        # ssh_idle_timeout (down to 0), so pin explicitly rather than rely on a
        # cross-setting invariant.
        # Bounded and unbounded paths share the explicit-create_process and
        # terminate-on-timeout cleanup, so a TimeoutError never leaves a remote
        # process parked on the connection. Only the bounded path caps kept bytes.
        cap = max_output_bytes if (max_output_bytes is not None and max_output_bytes > 0) else None

        async with self._pinned(conn):
            out_parts: list[bytes] = []
            err_parts: list[bytes] = []
            out_seen = 0
            err_seen = 0
            # One kept-budget shared by stdout and stderr so the *combined* buffer
            # stays within `cap`. Per-stream budgets let peak memory reach 2x cap,
            # but fanout's sizing math assumes `cap`. Reading `cap - kept[0]` and
            # updating `kept[0]` have no `await` between them, so the two
            # concurrent drains cannot interleave there.
            kept = [0]

            async def _drain(stream: Any, parts: list[bytes], seen: int, kept: list[int]) -> int:
                while True:
                    chunk = await stream.read(65536)
                    if not chunk:
                        return seen
                    seen += len(chunk)
                    if cap is None:
                        parts.append(chunk)
                        kept[0] += len(chunk)
                    else:
                        budget = cap - kept[0]
                        if budget > 0:
                            piece = chunk[:budget]
                            parts.append(piece)
                            kept[0] += len(piece)

            proc: Any | None = None

            async def _open_and_drain() -> tuple[int, int]:
                # create_process is inside the same wait_for envelope so a server
                # that accepts the connection but stalls on process creation is
                # still bounded by ``timeout``.
                nonlocal proc
                proc = await conn.create_process(command, encoding=None)
                return await asyncio.gather(
                    _drain(proc.stdout, out_parts, out_seen, kept),
                    _drain(proc.stderr, err_parts, err_seen, kept),
                )

            try:
                out_seen, err_seen = await asyncio.wait_for(_open_and_drain(), timeout)
                assert proc is not None  # narrows the Optional; set by _open_and_drain
                # wait_closed needs its own bound: a misbehaving peer can hold the
                # channel open after EOF. The output is in hand, so a lingering
                # channel is not a command timeout: keep it (exit status may be unknown).
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(proc.wait_closed(), _WAIT_CLOSED_TIMEOUT)
            except TimeoutError:
                # Terminate so the remote process does not park on the connection
                # until it dies; bound the post-terminate wait so cleanup cannot
                # hang. ``proc`` is None if the timeout fired during create_process.
                if proc is not None:
                    with contextlib.suppress(Exception):
                        proc.terminate()
                    # SIGTERM only reaches a cooperative direct child; closing the
                    # channel also releases the session slot on the shared connection.
                    with contextlib.suppress(Exception):
                        proc.close()
                    with contextlib.suppress(Exception):
                        await asyncio.wait_for(proc.wait_closed(), 2)
                return (f"[TIMEOUT after {timeout}s] {_TIMEOUT_OUTCOME_UNKNOWN}", None)
            except asyncio.CancelledError:
                # Caller went away: best-effort terminate rather than leave the
                # command on the shared connection, then propagate for audit.
                if proc is not None:
                    with contextlib.suppress(Exception):
                        proc.terminate()
                raise
            out = b"".join(out_parts).decode("utf-8", "replace") + b"".join(err_parts).decode(
                "utf-8", "replace"
            )
            if cap is not None and out_seen + err_seen > cap:
                out = truncate(out, cap)
            code = proc.exit_status
            return (str(out), int(code) if isinstance(code, int) else None)

    async def open_process(
        self,
        target: str,
        *,
        command: str,
        cols: int,
        rows: int,
        connect_kwargs: dict[str, Any],
    ) -> SshProcessTransport:
        conn = await self.connect(target, **connect_kwargs)
        proc = await conn.create_process(
            command or None,
            term_type="xterm-256color",
            term_size=(cols, rows),
            encoding=None,
        )
        # The session drives the channel directly and never re-connects, so pin
        # the connection for its lifetime; the transport releases it in aclose().
        try:
            entry = await self._pin(conn)
        except BaseException:
            # Cancelled or failed before a transport owns the channel: release
            # the remote PTY here, nobody else holds a reference.
            with contextlib.suppress(Exception):
                proc.terminate()
            with contextlib.suppress(Exception):
                proc.close()
            raise
        return SshProcessTransport(proc, pool=self, entry=entry)

    async def _sftp_transfer(
        self,
        target: str,
        *,
        upload: bool,
        src: str,
        dst: str,
        route: str,
        recurse: bool,
        connect_kwargs: dict[str, Any],
        timeout: int,
    ) -> str:
        """Shared body of :meth:`sftp_put` / :meth:`sftp_get`; ``route`` names the transfer."""
        conn = await self.connect(target, **connect_kwargs)
        # With timeout=0 a transfer is bounded only by keepalive, so it must not
        # be idle-evicted mid-transfer.
        async with self._pinned(conn):
            async with conn.start_sftp_client() as sftp:
                move = sftp.put if upload else sftp.get
                transfer = move(src, dst, recurse=recurse, preserve=True)
                # ``timeout`` caps the transfer itself; 0 disables it. wait_for
                # cancels a hung transfer and the context manager closes the client.
                if timeout > 0:
                    try:
                        await asyncio.wait_for(transfer, timeout)
                    except TimeoutError:
                        kind = "upload" if upload else "download"
                        return (
                            f"[TIMEOUT after {timeout}s] {_TIMEOUT_OUTCOME_UNKNOWN}; "
                            f"partial {kind} {route}"
                        )
                else:
                    await transfer
            return f"{'uploaded' if upload else 'downloaded'} {route}"

    async def sftp_put(
        self,
        target: str,
        local: str,
        remote: str,
        *,
        recurse: bool,
        connect_kwargs: dict[str, Any],
        timeout: int = 0,
    ) -> str:
        return await self._sftp_transfer(
            target,
            upload=True,
            src=local,
            dst=remote,
            route=f"{local} -> {target}:{remote}",
            recurse=recurse,
            connect_kwargs=connect_kwargs,
            timeout=timeout,
        )

    async def sftp_get(
        self,
        target: str,
        remote: str,
        local: str,
        *,
        recurse: bool,
        connect_kwargs: dict[str, Any],
        timeout: int = 0,
    ) -> str:
        return await self._sftp_transfer(
            target,
            upload=False,
            src=remote,
            dst=local,
            route=f"{target}:{remote} -> {local}",
            recurse=recurse,
            connect_kwargs=connect_kwargs,
            timeout=timeout,
        )

    @staticmethod
    def _parse_forward_spec(spec: str) -> tuple[str, int, str, int]:
        """Parse an L/R/D forward spec into (kind, listen_port, dest_host, dest_port).

        Raises a controlled ``ValueError`` (not a raw "invalid literal for int()"
        or unpack error) on a malformed spec, so the surfaced message stays
        bounded (QUAL-2). ``D`` (dynamic SOCKS) has no destination; it returns
        host="" port=0.
        """
        kind, _, rest = spec.partition(":")
        kind = kind.upper().strip()
        if kind in ("L", "R"):
            try:
                lport_s, dhost, dport_s = rest.split(":")
                return kind, int(lport_s), dhost, int(dport_s)
            except ValueError:
                raise ValueError(
                    f"invalid {kind} forward spec; expected "
                    f"{kind}:<listen_port>:<dest_host>:<dest_port>"
                ) from None
        if kind == "D":
            try:
                return "D", int(rest), "", 0
            except ValueError:
                raise ValueError("invalid D forward spec; expected D:<listen_port>") from None
        raise ValueError("forward spec must start with L:, R: or D:")

    async def add_forward(
        self, target: str, spec: str, *, connect_kwargs: dict[str, Any]
    ) -> ForwardHandle:
        # Validate before connecting so a malformed spec fails fast (QUAL-2).
        kind, lport, dhost, dport = self._parse_forward_spec(spec)
        # Cap active forwards (SSH-3): a persuaded client looping ssh_forward
        # would otherwise exhaust local fds / listen ports. This pre-check fails
        # fast before dialling; the authoritative check under the lock below
        # closes the listener if a concurrent caller took the last slot.
        cap = self.settings.max_forwards
        async with self._lock:
            if len(self._forwards) >= cap:
                raise ForwardError(
                    f"forward limit reached ({cap}); close an existing forward first"
                )
        conn = await self.connect(target, **connect_kwargs)
        # Pinned for the forward's lifetime (released in close_forward). Unpinned
        # on any failure before the handle is tracked, so a listener error or lost
        # cap race cannot leak a pin that keeps the connection alive forever.
        entry = await self._pin(conn)
        listener: Any = None
        try:
            fid = gen_id("fwd")
            if kind == "L":
                listener = await conn.forward_local_port(_LOOPBACK, lport, dhost, dport)
                handle = ForwardHandle(
                    fid, "local", spec, listener.get_port(), f"{dhost}:{dport}", listener, entry
                )
            elif kind == "R":
                listener = await conn.forward_remote_port("", lport, dhost, dport)
                handle = ForwardHandle(
                    fid, "remote", spec, listener.get_port(), f"{dhost}:{dport}", listener, entry
                )
            else:  # D (validated above)
                listener = await conn.forward_socks(_LOOPBACK, lport)
                handle = ForwardHandle(
                    fid, "dynamic", spec, listener.get_port(), "socks", listener, entry
                )
            async with self._lock:
                if len(self._forwards) >= cap:
                    with contextlib.suppress(Exception):
                        listener.close()
                        await listener.wait_closed()
                    raise ForwardError(
                        f"forward limit reached ({cap}); close an existing forward first"
                    )
                self._forwards[fid] = handle
            return handle
        except BaseException:
            # An untracked listener has no forward id for ssh_forward_close to
            # name and would keep its port for the life of the connection.
            # Closing twice (the cap-race branch above) is harmless.
            if listener is not None:
                with contextlib.suppress(Exception):
                    listener.close()
            await self._unpin(entry)
            raise

    def list_forwards(self) -> list[dict[str, object]]:
        return [
            {
                "id": h.id,
                "kind": h.kind,
                "spec": h.spec,
                "listen_port": h.listen_port,
                "target": h.target,
            }
            for h in self._forwards.values()
        ]

    def forward_count(self) -> int:
        """Number of currently-tracked SSH port forwards, for /metrics."""
        return len(self._forwards)

    async def close_forward(self, fid: str) -> str:
        async with self._lock:
            handle = self._forwards.pop(fid, None)
        if handle is None:
            return f"[ERROR: unknown forward: {fid}]"
        with contextlib.suppress(Exception):
            handle.listener.close()
            await handle.listener.wait_closed()
        await self._unpin(handle.entry)
        return f"closed forward {fid}"

    async def close_all(self) -> None:
        async with self._lock:
            forwards = list(self._forwards.values())
            entries = list(self._conns.values())
            pending = list(self._pending.values())
            self._forwards.clear()
            self._conns.clear()
            self._pending.clear()
        for fut in pending:
            if not fut.done():
                fut.cancel()
        for handle in forwards:
            with contextlib.suppress(Exception):
                handle.listener.close()
        for entry in entries:
            with contextlib.suppress(Exception):
                entry.conn.close()
