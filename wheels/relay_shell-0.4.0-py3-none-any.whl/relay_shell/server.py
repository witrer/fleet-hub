"""Server assembly: MCPServer instance, the audited tool runner, all tools.

Every tool runs through one path:

1. resolve request/client id from the MCP context (best-effort);
2. classify + admit via the policy layer (deny list first, always);
3. execute the work, never letting an exception reach the transport;
4. truncate to the output budget, prefix ``[exit N]`` when meaningful;
5. append one audit record (hash of the output, never the body).

This mirrors a production gateway: a tool can fail, time out, or be denied,
but it always returns a single bounded, audited string.
"""

from __future__ import annotations

import asyncio
import contextlib
import ipaddress
import json
import logging
import os
import pwd
import re
import shlex
import signal
import socket
from collections.abc import Awaitable, Callable, Sequence
from pathlib import Path
from typing import Any

from mcp.server.auth.middleware.auth_context import get_access_token
from mcp.server.mcpserver import Context, MCPServer

from . import __version__, seccomp
from .audit import AuditLogger
from .auth.resource import ResourceBoundMCPServer
from .broker import ConfirmationBroker
from .config import Settings, get_settings
from .errors import RelayError, fmt_exc
from .inventory import Inventory
from .metrics import ACTIVE_FORWARDS, ACTIVE_SESSIONS, AUDIT_DEGRADED, Metrics
from .notices import (
    attach_notices,
    call_notices,
    config_warnings,
    unverified_host_notice,
)
from .policy import Policy, Tier, classify
from .redaction import redact_args
from .sessions import LocalPtyTransport, Session, SessionRegistry, Transport
from .shelltools import build_env, run_command, run_script, spawn_argv
from .sshpool import SshPool
from .util import clamp, sha256_hex, truncate

__all__ = ["Relay", "build_server"]

_log = logging.getLogger("relay_shell.server")

Work = Callable[[], Awaitable[tuple[str, int | None]]]
_SUDO_SEARCH_PATHS = (Path("/usr/bin/sudo"), Path("/bin/sudo"), Path("/usr/local/bin/sudo"))

# ssh_fanout: per-call host cap. Without it one call could open hundreds of SSH
# connections (each with its own credential negotiation and remote sshd auth log
# entry), making the tool a noisy sweep surface.
_SSH_FANOUT_MAX_HOSTS = 100

# ssh_check (SSH-2): per-call host cap and bounded probe concurrency. Without the
# cap the inventory-wide default could fan a large fleet into one call; without
# concurrency the probes ran sequentially, so a long list multiplied by the
# connect timeout blocked the call. The probe is read-only ("echo ok"); output
# order follows the input list regardless of completion order.
_SSH_CHECK_MAX_HOSTS = 100
_SSH_CHECK_CONCURRENCY = 8
# PERF-4: bound the per-host buffered output. ssh_check is Tier 0 (permitted even
# in `readonly` mode) and `hosts` is caller-chosen, so a malicious remote sshd
# could otherwise stream unbounded data on the exec channel, up to
# `_SSH_CHECK_CONCURRENCY` streams at once. Only the "ok" substring is inspected.
_SSH_CHECK_PER_HOST_OUTPUT_CAP = 4096

# ssh_keyscan: host tokens are validated at the boundary so the shell
# concatenation is safe. Hostnames and bracketed IPv6 literals only; no
# whitespace, shell metacharacters or path separators.
_HOSTNAME_RE = re.compile(r"^[A-Za-z0-9._\-\[\]:]+$")

# ssh_keyscan: key types accepted (algorithms in current OpenSSH); anything else
# is rejected at the boundary.
_ALLOWED_KEY_TYPES = frozenset({"rsa", "ecdsa", "ed25519", "dsa"})

# ssh_keyscan: per-call host cap. Without it one call could send thousands of
# outbound TCP SYNs, a network-burst surface even at Tier 1.
_SSH_KEYSCAN_MAX_HOSTS = 32


def _find_sudo_binary() -> str:
    """Return an executable sudo path from well-known locations, or ``""``.

    This is informational metadata for ``server_info`` only; command execution
    behavior does not depend on this lookup.
    """
    for path in _SUDO_SEARCH_PATHS:
        if path.is_file() and os.access(path, os.X_OK):
            return str(path)
    return ""


def _confirm_op_key(policy_text: str, audit_args: dict[str, Any]) -> str:
    """Full operation identity for the Tier-3 confirmation broker (ADR 0009).

    A confirmation token must authorize the *exact* call, so the key binds both
    the command/content the executor runs (``policy_text``) **and** a canonical
    serialization of every audited argument. ``audit_args`` carries the
    operation's *target* - the ``host`` for the SSH tools, ``hosts`` for
    ``ssh_fanout``, ``cwd`` for the shell tools, ``session_id`` for
    ``session_send``, ``local``/``remote`` for the transfer tools - which
    ``policy_text`` deliberately omits (it is the command-content probe the deny
    list and tier classifier see). Binding to both closes the confused-deputy
    gap where a token armed for one target could be consumed against another
    (e.g. confirm ``cwd=/tmp`` then execute ``cwd=/``, or confirm one host then
    fan out to the whole inventory). The raw (un-redacted) args are used so
    redaction never collapses two distinct operations to the same key; the key
    is only hashed for the token binding, never logged.
    """
    canonical = json.dumps(
        audit_args, sort_keys=True, separators=(",", ":"), default=str, ensure_ascii=False
    )
    return f"{policy_text}\x00{canonical}"


def _filter_audit_records(text: str, tool: str, tier: int, denied: bool | None) -> str:
    """Keep the JSONL audit records in ``text`` that match the given filters.

    ``tool`` exact-matches the record's ``tool`` (empty = any); ``tier`` matches
    the integer tier (``< 0`` = any); ``denied`` matches the boolean
    ``denied`` field (``None`` = any). Order is preserved. A line that is not
    valid JSON is dropped while filtering (the on-disk log is well-formed JSONL;
    this is defensive against a torn final write). Used only by the read-only
    ``audit_tail`` view — never on the write path.
    """
    out: list[str] = []
    # split on \n only: str.splitlines() also breaks on U+2028/U+2029/U+0085, which
    # json.dumps(ensure_ascii=False) writes raw, fragmenting that record.
    for line in text.split("\n"):
        if not line.strip():
            continue
        try:
            rec = json.loads(line)
        except (json.JSONDecodeError, ValueError):
            continue
        if tool and rec.get("tool") != tool:
            continue
        if tier >= 0 and rec.get("tier") != tier:
            continue
        if denied is not None and bool(rec.get("denied", False)) != denied:
            continue
        out.append(line)
    return "\n".join(out)


def _ctx_ids(ctx: Context | None) -> tuple[str, str]:
    """Keep request correlation separate from verified OAuth attribution.

    Request metadata is caller-controlled. Only the SDK authentication
    middleware's access token can supply an authenticated client identity.
    """
    request_id = ""
    if ctx is not None:
        with contextlib.suppress(Exception):
            value = getattr(ctx, "request_id", None)
            if value is not None:
                request_id = str(value)
    token = get_access_token()
    return request_id, token.client_id if token is not None else ""


# --- policy_text builders (runbook R-002) ------------------------------------
#
# The admission contract is: every byte the executor will see, the policy
# layer sees first (deny list, then the tier heuristics). Each tool with a
# non-empty policy surface builds its probe text through exactly one function
# here, so the contract is greppable per tool and pinned by
# tests/test_tool_wrappers.py::test_policy_text_builders_*. A tool wrapper
# never assembles policy text inline.


def _policy_text_shell_exec(command: str, stdin: str, env_json: str) -> str:
    """The command line, its stdin, and the env overlay (LD_PRELOAD, PATH...)."""
    return "\n".join(part for part in (command, stdin, env_json) if part)


def _policy_text_shell_script(script: str, env_json: str) -> str:
    """The script body (it becomes the interpreter's stdin) and the env overlay."""
    return "\n".join(part for part in (script, env_json) if part)


def _policy_text_shell_spawn(command: str, env_json: str) -> str:
    """The spawned command and the env overlay shaping the PTY's environment."""
    return "\n".join(part for part in (command, env_json) if part)


# The SSH command tools fold the *destination host* into the deny probe (F2),
# closing the asymmetry with the transfer tools: `RELAY_SHELL_POLICY_DENY` is
# the documented way to block an SSH tool from reaching a host (e.g. the cloud
# metadata IP), and it must work for the tools that grant remote execution, not
# only for upload/download/forward/keyscan. Widened with the host's canonical IP
# forms (SSRF-1/2). Tradeoff (SEC-1, accepted): the tier classifier also sees
# the host, so a host embedding a destructive word at a token start
# over-classifies (bites only `guarded`; `RELAY_SHELL_POLICY_ALLOW` is the
# escape hatch). The command stays first so its tier tokens classify as before.
def _jump_hosts(jump: str) -> list[str]:
    """Bare host names of a ``user@host:port[,hop2...]`` jump chain (for IP widening)."""
    hosts: list[str] = []
    for hop in jump.replace(",", " ").split():
        hop = hop.rsplit("@", 1)[-1]
        if hop.count(":") == 1:  # host:port (a bare IPv6 literal has several colons)
            hop = hop.split(":", 1)[0]
        hosts.append(hop)
    return hosts


def _with_jump(text: str, jump: str) -> tuple[str, list[str]]:
    """Append the jump chain to a probe: it is dialled before the destination, so the
    deny list must see it. Empty ``jump`` leaves the probe byte-identical."""
    return (f"{text}\n{jump}", _jump_hosts(jump)) if jump else (text, [])


def _policy_text_ssh_exec(host: str, command: str, jump: str = "") -> str:
    """The remote command line plus the destination host (and jump chain)."""
    text, hops = _with_jump(f"{command}\n{host}", jump)
    return _with_canonical_ips(text, host, *hops)


def _policy_text_ssh_spawn(host: str, command: str, jump: str = "") -> str:
    """The remote command (empty = login shell) plus the destination host (and jump)."""
    text, hops = _with_jump(f"{command}\n{host}", jump)
    return _with_canonical_ips(text, host, *hops)


def _policy_text_ssh_fanout(hosts: str, command: str) -> str:
    """The fanned-out command plus every target host, for the deny list.

    ``hosts`` is a comma/space-separated list; each token is canonical-IP
    widened (SSRF-1) like ``ssh_keyscan`` so a fleet target cannot dodge an IP
    deny by an alternate spelling.
    """
    tokens = [t for t in hosts.replace(",", " ").split() if t]
    return _with_canonical_ips(f"{command}\n{hosts}", *tokens)


def _policy_text_ssh_check(hosts: str) -> str:
    """The probed host list, for the deny list (F2).

    ``ssh_check`` is Tier 0, so folding the hosts in does not change tier
    classification (it stays read-only) — it only lets `RELAY_SHELL_POLICY_DENY`
    gate which hosts may be probed, matching the other SSH tools.
    """
    tokens = [t for t in hosts.replace(",", " ").split() if t]
    return _with_canonical_ips(hosts, *tokens)


def _policy_text_session_send(data: str, pending: str = "") -> str:
    """What the PTY will have on its line once ``data`` is written.

    ``pending`` is the partial line already typed (nothing since the last Enter), so
    a command split across several sends (``r`` then ``m -rf /x``) is classified as
    the whole line the shell will run, not as innocuous fragments.
    """
    return pending + data


def _policy_text_ssh_upload(host: str, local_path: str, remote_path: str, jump: str = "") -> str:
    """A synthetic ``upload`` phrase naming both endpoints, for the deny list.

    Widened with the canonical IP of ``host`` (SSRF-2) so an IP deny is not
    dodged by a decimal/hex/octal/IPv4-mapped spelling of the destination.
    """
    text, hops = _with_jump(f"upload {local_path} {host}:{remote_path}", jump)
    return _with_canonical_ips(text, host, *hops)


def _policy_text_ssh_download(host: str, remote_path: str, local_path: str, jump: str = "") -> str:
    """A synthetic ``download`` phrase naming both endpoints, for the deny list.

    Widened with the canonical IP of ``host`` (SSRF-2), as in ``ssh_upload``.
    """
    text, hops = _with_jump(f"download {host}:{remote_path} {local_path}", jump)
    return _with_canonical_ips(text, host, *hops)


def _policy_text_ssh_forward(spec: str, host: str = "", jump: str = "") -> str:
    """A synthetic ``forward`` phrase carrying the spec, for the deny list.

    Widened with the canonical IP of the forward's destination host (SSRF-2):
    an ``L:/R:`` forward dials ``dhost``, so an IP deny on, say, the cloud
    metadata address should catch it however the caller spelled it.
    """
    text, hops = _with_jump(f"forward {spec}", jump)
    if host:
        text = f"{text}\n{host}"
    return _with_canonical_ips(text, _forward_dhost(spec), *([host] if host else []), *hops)


# Every host-list tool caps its host count well below this (<= 100) and refuses longer
# lists, so canonicalizing more tokens would only add quadratic work before admission.
_MAX_CANON_TOKENS = 128


def _canonical_ips(token: str) -> list[str]:
    """Canonical IP form(s) a *literal-IP* host token encodes (no DNS).

    SSRF-1: ``RELAY_SHELL_POLICY_DENY`` matches the probe *text*, so a caller
    can dodge an IP-based deny by spelling the same address another way the OS
    resolver still accepts — decimal (``2130706433``), hex (``0x7f000001`` /
    ``0x7f.0.0.1``), octal (``0177.0.0.1``), dotted-short (``127.1``), or
    IPv4-mapped IPv6 (``::ffff:127.0.0.1``). This returns the canonical
    dotted/colon form(s) of any literal IP a token encodes so the caller can
    append them to the probe and an operator's IP deny catches every spelling.

    Hostnames return ``[]``: we never resolve DNS here — that would block the
    event loop and a rebinding answer could differ from the one the eventual
    connection dials. Hard egress control needs a network firewall, not a text
    deny (see ``docs/deployment.md``). Purely additive — a stray canonical form
    only *widens* what a deny can match; it never admits or blocks on its own.
    """
    t = token.strip().strip("[]")
    if not t:
        return []
    found: list[str] = []
    # Standard IPv4 / IPv6 (incl. IPv4-mapped). Strict: a bare port like "22"
    # raises here, so small integers are not mis-canonicalised.
    try:
        ip = ipaddress.ip_address(t)
        found.append(str(ip))
        mapped = getattr(ip, "ipv4_mapped", None)
        if mapped is not None:
            found.append(str(mapped))
    except ValueError:
        pass
    # Obfuscated IPv4 the libc resolver still accepts (inet_aton grammar:
    # decimal / octal / hex / short). Gate on an "IP-ish" shape so a bare
    # port or small count is not turned into 0.0.0.N noise.
    looks_ipish = "." in t or t.lower().startswith("0x") or (t.isdigit() and int(t) > 65535)
    if looks_ipish:
        with contextlib.suppress(OSError):
            found.append(socket.inet_ntoa(socket.inet_aton(t)))
    return list(dict.fromkeys(found))


def _with_canonical_ips(text: str, *host_tokens: str) -> str:
    """Append the canonical IP form of any of ``host_tokens`` to a probe ``text``.

    So an IP-based ``RELAY_SHELL_POLICY_DENY`` matches the address regardless of
    the encoding the caller used (SSRF-1/SSRF-2). Only forms that *differ* from
    what the caller wrote and are not already present are appended, keeping the
    probe clean for plain literals and hostnames. The caller passes the exact
    host tokens (rather than re-tokenizing ``text``) so colon-bearing literals —
    an IPv6 address, or a ``host:path`` / ``L:port:dhost:port`` phrase — are
    canonicalized as whole tokens instead of being split apart.
    """
    extra: list[str] = []
    for tok in host_tokens[:_MAX_CANON_TOKENS]:
        for ip in _canonical_ips(tok):
            if ip != tok and ip not in extra and ip not in text:
                extra.append(ip)
    return f"{text} {' '.join(extra)}" if extra else text


def _augment_probe_with_ips(hosts: str) -> str:
    """Widen an ``ssh_keyscan`` host-list probe with canonical IP forms (SSRF-1).

    The host list is whitespace/comma-separated; each entry is a candidate host
    token fed to :func:`_with_canonical_ips`.
    """
    tokens = [t for t in hosts.replace(",", " ").split() if t]
    return _with_canonical_ips(hosts, *tokens)


def _forward_dhost(spec: str) -> str:
    """Best-effort destination host from an ``L:/R:`` forward spec (else "").

    ``L:lport:dhost:dport`` / ``R:rport:dhost:dport`` name a destination host
    the forward dials; ``D:lport`` (dynamic SOCKS) names none. Lenient and
    parse-free (the authoritative parse + validation happens later in
    ``SshPool.add_forward``): a malformed spec just yields no dhost, so the
    probe is only ever *widened*, never broken.
    """
    parts = spec.split(":")
    if len(parts) >= 4 and parts[0].strip().upper() in ("L", "R"):
        return parts[2]
    return ""


def _policy_text_ssh_keyscan(hosts: str) -> str:
    """The caller-chosen scan targets, so the deny list gates them (SEC-1).

    ``ssh_keyscan`` opens caller-chosen outbound TCP connections — the
    SSRF-shaped surface most worth gating by host — yet its probe text used to
    be empty, so ``RELAY_SHELL_POLICY_DENY`` never saw the targets (unlike the
    ``ssh_upload`` / ``ssh_download`` / ``ssh_forward`` synthetic builders,
    which already name their host). Returning the ``hosts`` string closes that
    gap and honours the runbook R-002 contract ("everything the executor sees,
    the policy sees"). It is also widened with the canonical form of any literal
    IP the caller wrote in an alternate encoding (SSRF-1, via
    ``_augment_probe_with_ips``) so an IP deny is not dodged by
    decimal/hex/octal/IPv4-mapped spellings. Tradeoff: the same text feeds the
    tier classifier, so a host whose name embeds a heuristic word (``reboot``,
    ``sudo``, ...) at a token start over-classifies the scan and is refused in
    ``guarded`` mode (``open`` is advisory; ``readonly`` already refuses
    Tier 1). That is a conservative false-deny with ``RELAY_SHELL_POLICY_ALLOW``
    as the escape hatch, and it matches how the transfer tools already behave.
    """
    return _augment_probe_with_ips(hosts)


class Relay:
    """Holds shared state and runs every tool through the audited path."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.audit = AuditLogger(
            settings.audit_path,
            also_stderr=settings.audit_stderr,
            fmt=settings.audit_format,
            chain=settings.audit_chain,
        )
        self.policy = Policy(settings.policy_mode, settings.policy_deny, settings.policy_allow)
        # Tier-3 confirmation broker (ADR 0009). None unless opted in; the default
        # configuration never consults it.
        self.broker = ConfirmationBroker(settings.confirm_ttl) if settings.confirm_tier3 else None
        self.inventory = Inventory(settings.ssh_config, settings.inventory).load()
        self.sessions = SessionRegistry(
            settings.max_sessions,
            settings.session_idle_timeout,
            settings.session_buffer_bytes,
        )
        self.ssh = SshPool(settings=settings, inventory=self.inventory)
        self.sudo_binary = _find_sudo_binary()
        self.metrics = Metrics()
        # Gauges are read live at scrape time so /metrics matches the registries.
        self.metrics.register_gauge(ACTIVE_SESSIONS, lambda: float(self.sessions.count()))
        self.metrics.register_gauge(ACTIVE_FORWARDS, lambda: float(self.ssh.forward_count()))
        self.metrics.register_gauge(AUDIT_DEGRADED, lambda: 1.0 if self.audit.degraded else 0.0)
        # Announce the seccomp-notify channel status once, so an operator who set
        # RELAY_SHELL_SECCOMP_NOTIFY learns whether it engaged (or why it no-ops).
        if settings.seccomp_notify:
            support = seccomp.platform_support()
            if support.ok:
                _log.info(
                    "seccomp-notify audit channel ON (arch=%s, kernel=%s, cap=%d)",
                    support.arch,
                    support.kernel,
                    settings.seccomp_notify_cap,
                )
            else:
                _log.warning(
                    "seccomp-notify requested but unavailable (%s); the channel is "
                    "OFF and local spawns are unaffected",
                    support.reason,
                )

    def clamp_timeout(self, timeout: int) -> int:
        return clamp(timeout, 1, self.settings.max_timeout)

    def exec_timeout(self, timeout: int) -> int:
        """Per-call timeout for ``shell_exec`` / ``ssh_exec``: exactly ``0`` means the server
        default (``RELAY_SHELL_DEFAULT_TIMEOUT``); every other value, a negative one
        included, is clamped as usual (so a negative becomes the 1 s floor, never the default)."""
        return self.clamp_timeout(self.settings.default_timeout if timeout == 0 else timeout)

    def clamp_output(self, max_output: int) -> int:
        return clamp(max_output, 1024, self.settings.max_output_hard)

    async def run(
        self,
        *,
        tool: str,
        ctx: Context | None,
        audit_args: dict[str, Any],
        policy_text: str,
        max_output: int,
        work: Work,
        min_tier: Tier = Tier.READ_ONLY,
        extra_notices: Sequence[str] = (),
        json_notices: bool = False,
    ) -> str:
        """Admit, run and audit one call. ``extra_notices`` are tool-specific unsafe facts;
        ``json_notices`` puts the notices inside a JSON-object result instead of after it."""
        request_id, client_id = _ctx_ids(ctx)
        red = redact_args(audit_args)
        mode = self.settings.policy_mode
        if len(policy_text) > self.settings.max_input:
            # Refuse before any regex runs over it: the scan is synchronous (about
            # 0.5 s per MiB) and a partial scan would let padding hide a command.
            tier = classify(tool, "")
            body = (
                f"[DENIED tier {int(tier)} ({tier.name}): input is {len(policy_text)} "
                f"characters, over RELAY_SHELL_MAX_INPUT ({self.settings.max_input})]"
            )
            self.audit.record(
                tool=tool,
                args=red,
                output=body,
                exit_code=None,
                tier=int(tier),
                request_id=request_id,
                client_id=client_id,
                denied=True,
            )
            self.metrics.inc_tool_call(tool=tool, tier=int(tier), mode=mode, outcome="denied")
            return body
        decision = self.policy.check(tool, policy_text, min_tier)
        if not decision.allowed:
            body = f"[DENIED tier {int(decision.tier)} ({decision.tier.name}): {decision.reason}]"
            self.audit.record(
                tool=tool,
                args=red,
                output=body,
                exit_code=None,
                tier=int(decision.tier),
                request_id=request_id,
                client_id=client_id,
                denied=True,
            )
            self.metrics.inc_tool_call(
                tool=tool, tier=int(decision.tier), mode=mode, outcome="denied"
            )
            return body

        # Tier-3 confirmation gate (ADR 0009). Opt-in: skipped when `self.broker`
        # is None (the default). When enabled, an IRREVERSIBLE op that already
        # passed the deny list and mode check is not executed on first request:
        # the runner mints a single-use, TTL-bounded token (audited as
        # `confirm_plan`, no work() side effect) and the caller must arm it via
        # `operation_confirm`, then re-issue the exact same call. A retry whose
        # armed token is found is executed and tagged `confirm_execute`. An added
        # safeguard, never a bypass: deny list and mode policy ran above.
        confirm_action = ""
        if self.broker is not None and decision.tier == Tier.IRREVERSIBLE:
            op_key = _confirm_op_key(policy_text, audit_args)
            if self.broker.consume(tool, op_key, client_id):
                confirm_action = "confirm_execute"
            else:
                challenge = self.broker.plan(tool, op_key, client_id)
                body = (
                    f"[CONFIRM REQUIRED tier {int(decision.tier)} "
                    f"({decision.tier.name}): this irreversible operation needs a second "
                    f'step. Call operation_confirm(token="{challenge.token}") then re-issue '
                    f"this exact call within {challenge.ttl}s.]"
                )
                self.audit.record(
                    tool=tool,
                    args=red,
                    output=body,
                    exit_code=None,
                    tier=int(decision.tier),
                    request_id=request_id,
                    client_id=client_id,
                    action="confirm_plan",
                )
                self.metrics.inc_tool_call(
                    tool=tool, tier=int(decision.tier), mode=mode, outcome="confirm_required"
                )
                return body

        if self.settings.audit_intent:
            # Write-ahead record (opt-in): the executed-command trail survives a
            # relay crash or SIGKILL between here and the completion record.
            self.audit.record(
                tool=tool,
                args=red,
                output="",
                exit_code=None,
                tier=int(decision.tier),
                request_id=request_id,
                client_id=client_id,
                action="intent",
            )

        errored = False
        # Activate the per-call seccomp-notify monitor (ADR 0006) for work(). None
        # unless the channel is enabled and supported; executors consult it when
        # they spawn a child. A ContextVar isolates concurrent calls without
        # threading the monitor through every work closure. Whoever arms the
        # monitor stops it: the one-shot executor (shelltools) when the child is
        # reaped, a PTY transport (sessions) at session close (B-026).
        monitor = self._seccomp_monitor(request_id)
        token = seccomp.set_active(monitor)
        try:
            body, exit_code = await work()
        except asyncio.CancelledError:
            # A client disconnect, an MCP cancellation or a transport timeout
            # cancels the call mid-flight. The executors tear their child down
            # on cancellation, but the call must still leave an audit record
            # (the work may already have had effects), then propagate.
            self.audit.record(
                tool=tool,
                args=red,
                output="[CANCELLED]",
                exit_code=None,
                tier=int(decision.tier),
                request_id=request_id,
                client_id=client_id,
                action="cancelled",
            )
            self.metrics.inc_tool_call(
                tool=tool, tier=int(decision.tier), mode=mode, outcome="cancelled"
            )
            raise
        except RelayError as exc:
            body, exit_code = fmt_exc(exc), None
            errored = True
        except Exception as exc:  # noqa: BLE001
            body, exit_code = fmt_exc(exc), None
            errored = True
        finally:
            seccomp.clear_active(token)

        body = truncate(body, self.clamp_output(max_output))
        final = f"[exit {exit_code}]\n{body}" if exit_code is not None else body
        self.audit.record(
            tool=tool,
            args=red,
            output=final,
            exit_code=exit_code,
            tier=int(decision.tier),
            request_id=request_id,
            client_id=client_id,
            action=confirm_action,
        )
        outcome = "error" if errored else "ok"
        self.metrics.inc_tool_call(tool=tool, tier=int(decision.tier), mode=mode, outcome=outcome)
        if self.settings.unsafe_notices:
            # A message to the caller, appended after the audit record was written from
            # `final`: the record and the output hash do not change (ADR 0013).
            notes = [*call_notices(decision, audit_args), *extra_notices]
            return attach_notices(final, notes, as_json=json_notices)
        return final

    async def register_session(
        self, *, kind: str, title: str, transport: Transport, cols: int, rows: int
    ) -> Session:
        """Admit a freshly-spawned transport into the session registry.

        The shared registration path for ``shell_spawn`` / ``ssh_spawn``
        (runbook R-003). If the registry refuses — typically the session
        limit — the transport is closed before the error propagates, so the
        already-spawned child is reaped instead of leaking unsupervised.
        ``aclose()`` also releases the per-session seccomp monitor when one
        is attached (B-026).
        """
        try:
            return await self.sessions.add(
                kind=kind, title=title, transport=transport, cols=cols, rows=rows
            )
        except BaseException:
            with contextlib.suppress(Exception):
                await transport.aclose()
            raise

    def target_names(self, hosts: str) -> list[str]:
        """Hosts an ``ssh_check`` / ``ssh_fanout`` call addresses: the list, or the inventory."""
        if hosts.strip():
            return [h for h in hosts.replace(",", " ").split() if h]
        return [h.name for h in self.inventory.hosts()]

    def host_key_notices(self, names: Sequence[str]) -> list[str]:
        """Notice for the named hosts that would be dialled without host-key verification."""
        if not self.settings.unsafe_notices:
            return []
        unverified = [n for n in names[:200] if self.effective_known_hosts(n, "") == "ignore"]
        return unverified_host_notice(unverified)

    def ssh_target_audit(
        self, host: str, user: str, port: int, key_path: str, jump: str, known_hosts: str
    ) -> dict[str, Any]:
        """The connection-identity fields every single-host SSH tool puts in its audit args,
        in the order the records have always carried them (``known_hosts`` is the effective
        mode, not the raw argument)."""
        return {
            "user": user,
            "port": port,
            "key_path": key_path,
            "jump": jump,
            "known_hosts": self.effective_known_hosts(host, known_hosts),
        }

    def effective_known_hosts(self, host: str, known_hosts: str) -> str:
        """The verification mode ``SshPool.connect`` will actually use for ``host``.

        Same precedence as the pool (per-call, then the inventory entry, then the
        server default), so the audit record states what was enforced, including an
        inventory override that the per-call argument alone would not show.
        """
        try:
            inventory_mode = self.inventory.resolve(host).known_hosts
        except Exception:  # noqa: BLE001 - audit helper must never fail the call
            inventory_mode = None
        # str(): an inventory entry is operator JSON and may hold a non-string; the audit
        # helper must never raise outside the audited runner (the pool still refuses it).
        return str(known_hosts or inventory_mode or self.settings.ssh_known_hosts).lower()

    def connect_kwargs(
        self,
        user: str,
        port: int,
        key_path: str,
        known_hosts: str,
        jump: str,
        connect_timeout: int = 0,
    ) -> dict[str, Any]:
        """Build the dict that ``SshPool.connect`` accepts as ``**kwargs``.

        ``connect_timeout`` is an optional overlay for tools like
        ``ssh_check`` and ``ssh_fanout`` that probe many hosts at once
        and want a tighter per-host bound than ``settings.ssh_connect_timeout``.
        A zero overlay means "fall back to the server-wide default" —
        the same semantics ``SshPool.connect`` already implements, so
        callers do not have to special-case it.
        """
        ck: dict[str, Any] = {
            "user": user,
            "port": port,
            "key_path": key_path,
            "known_hosts": known_hosts,
            "jump": jump,
        }
        if connect_timeout > 0:
            ck["connect_timeout"] = connect_timeout
        return ck

    def _seccomp_monitor(self, request_id: str) -> seccomp.SeccompMonitor | None:
        """Build a per-call seccomp-notify monitor, or ``None`` if disabled.

        ``None`` whenever the channel is off (the default) or the host lacks
        the prerequisites (Linux/x86_64/kernel 5.5+/CAP_SYS_ADMIN), so the
        spawn path stays byte-identical. When active, every observed syscall
        is routed to the audit log (an additive ``syscall_notify`` line tied
        to this ``request_id``) and the bounded ``/metrics`` counters. For a
        PTY spawn the monitor outlives the call — the session transport
        adopts it (B-026) — so its events keep carrying the *spawning*
        call's ``request_id`` for the life of the session.
        """
        if not self.settings.seccomp_notify:
            return None
        support = seccomp.platform_support()
        if not support.ok:
            return None

        def _on_event(evt: seccomp.SyscallEvent) -> None:
            self.audit.record_syscall(
                pid=evt.pid,
                syscall=evt.syscall,
                nr=evt.nr,
                args=evt.args,
                request_id=request_id,
            )
            self.metrics.inc_seccomp_event(syscall=evt.syscall)

        def _on_overflow(pid: int) -> None:
            self.audit.record_syscall_overflow(
                pid=pid, cap=self.settings.seccomp_notify_cap, request_id=request_id
            )
            self.metrics.inc_seccomp_overflow()

        return seccomp.SeccompMonitor(
            cap=self.settings.seccomp_notify_cap,
            arch=support.arch,
            on_event=_on_event,
            on_overflow=_on_overflow,
            on_degraded=lambda reason: self.audit.mark_degraded(f"seccomp-notify: {reason}"),
        )


def http_transport_kwargs(settings: Settings) -> dict[str, Any]:
    """Transport options for ``MCPServer.run(transport="streamable-http")``.

    In MCP SDK v2 the bind address and the streamable-HTTP response shape
    are no longer constructor arguments; they are passed per transport at
    run time. Kept here beside the server so the serve entrypoint does not
    have to know which options the HTTP transport takes.
    """
    return {
        "host": settings.http_host,
        "port": settings.http_port,
        "stateless_http": True,
        "json_response": True,
    }


def build_server(settings: Settings | None = None) -> MCPServer:
    """Construct the MCPServer with every tool registered."""
    cfg = settings or get_settings()
    app = Relay(cfg)

    server_kwargs: dict[str, Any] = {
        "instructions": _INSTRUCTIONS,
    }
    if cfg.transport == "http" and cfg.auth_enabled:
        from .auth import build_auth_settings, make_oauth_provider

        server_kwargs["auth"] = build_auth_settings(cfg.auth_issuer, cfg.auth_resource_url or None)
        server_kwargs["auth_server_provider"] = make_oauth_provider(cfg)

    mcp = ResourceBoundMCPServer("relay-shell", **server_kwargs)

    # ---- local shell -------------------------------------------------------
    @mcp.tool()
    async def shell_exec(
        command: str,
        timeout: int = 0,
        max_output: int = 65536,
        cwd: str = "",
        stdin: str = "",
        merge_stderr: bool = True,
        use_shell: bool = True,
        env_json: str = "",
        ctx: Context | None = None,
    ) -> str:
        """Run one non-interactive shell command on the local host; returns its combined output.

        Use for a command that runs and exits on its own. For an interactive
        or long-lived program that needs a TTY (a REPL, a pager, a prompt) use
        ``shell_spawn``; for several statements or a non-bash interpreter use
        ``shell_script``.

        Timeout and output size are clamped to the server limits; ``timeout=0``
        uses the server default (60 s unless configured). Set
        ``use_shell=false`` to exec an argv without a shell.
        """
        t = app.exec_timeout(timeout)
        policy_text = _policy_text_shell_exec(command, stdin, env_json)
        return await app.run(
            tool="shell_exec",
            ctx=ctx,
            audit_args={
                "command": command,
                "timeout": t,
                "cwd": cwd,
                "use_shell": use_shell,
                "stdin": stdin,
                "env_json": env_json,
            },
            policy_text=policy_text,
            max_output=max_output,
            work=lambda: run_command(
                command,
                timeout=t,
                cwd=cwd,
                stdin=stdin,
                merge_stderr=merge_stderr,
                use_shell=use_shell,
                env_json=env_json,
                output_cap=app.settings.max_output_hard,
            ),
        )

    @mcp.tool()
    async def shell_script(
        script: str,
        interpreter: str = "bash",
        strict: bool = True,
        timeout: int = 120,
        cwd: str = "",
        env_json: str = "",
        ctx: Context | None = None,
    ) -> str:
        """Run a multi-line script (bash/sh/python) fed on stdin; returns its output.

        Use when you have several statements or need a non-bash interpreter.
        For a single command use ``shell_exec``; for interactive or long-lived
        work that needs a TTY use ``shell_spawn``.

        With ``strict`` and a shell interpreter, ``set -euo pipefail`` (``set -eu``
        for ``sh``) is prepended so failures abort early.
        """
        t = app.clamp_timeout(timeout)
        policy_text = _policy_text_shell_script(script, env_json)
        return await app.run(
            tool="shell_script",
            ctx=ctx,
            audit_args={
                "interpreter": interpreter,
                "strict": strict,
                "script": script,
                "timeout": t,
                "cwd": cwd,
                "env_json": env_json,
            },
            policy_text=policy_text,
            max_output=65536,
            work=lambda: run_script(
                script,
                interpreter=interpreter,
                strict=strict,
                timeout=t,
                cwd=cwd,
                env_json=env_json,
                output_cap=app.settings.max_output_hard,
            ),
        )

    @mcp.tool()
    async def shell_spawn(
        command: str = "",
        cols: int = 120,
        rows: int = 40,
        cwd: str = "",
        env_json: str = "",
        ctx: Context | None = None,
    ) -> str:
        """Start a persistent local PTY session; returns a session id.

        Use when the work is interactive or long-lived and needs a real TTY: a
        REPL or TUI, a program that prompts (including a sudo password), or a
        job you start and watch. Drive the returned id with ``session_send`` /
        ``session_recv`` (``session_resize`` / ``session_kill`` /
        ``session_list`` to manage it) - spawning and the session tools are one
        workflow, not alternatives. For a one-shot command that just runs and
        exits, use ``shell_exec`` instead.
        """

        async def _work() -> tuple[str, int | None]:
            argv = spawn_argv(command)
            transport = await LocalPtyTransport.spawn(
                argv, cwd=cwd or None, env=build_env(env_json), cols=cols, rows=rows
            )
            sess = await app.register_session(
                kind="local",
                title=" ".join(argv),
                transport=transport,
                cols=cols,
                rows=rows,
            )
            return (
                f"session {sess.id} started ({' '.join(argv)}); "
                f"use session_recv/session_send with this id",
                None,
            )

        policy_text = _policy_text_shell_spawn(command, env_json)
        return await app.run(
            tool="shell_spawn",
            ctx=ctx,
            audit_args={
                "command": command or "/bin/bash",
                "size": f"{cols}x{rows}",
                "cwd": cwd,
                "env_json": env_json,
            },
            policy_text=policy_text,
            max_output=4096,
            work=_work,
        )

    # ---- ssh ---------------------------------------------------------------
    @mcp.tool()
    async def ssh_exec(
        host: str,
        command: str,
        timeout: int = 0,
        user: str = "",
        port: int = 0,
        key_path: str = "",
        known_hosts: str = "",
        jump: str = "",
        ctx: Context | None = None,
    ) -> str:
        """Run one non-interactive command on a remote host over SSH; returns its output.

        Use for a remote command that runs and exits on its own. For an
        interactive or long-lived remote program that needs a TTY use
        ``ssh_spawn``; to run one command across many hosts at once use
        ``ssh_fanout``.

        ``host`` may be an inventory/ssh_config alias or ``user@host``.
        ``known_hosts`` is ``strict`` | ``accept-new`` | ``ignore``. ``timeout=0``
        uses the server default (60 s unless configured).
        """
        t = app.exec_timeout(timeout)
        ck = app.connect_kwargs(user, port, key_path, known_hosts, jump)
        return await app.run(
            tool="ssh_exec",
            ctx=ctx,
            audit_args={
                "host": host,
                "command": command,
                "timeout": t,
                **app.ssh_target_audit(host, user, port, key_path, jump, known_hosts),
            },
            policy_text=_policy_text_ssh_exec(host, command, jump),
            max_output=65536,
            # PERF-4: bound the buffered remote output to the absolute ceiling
            # (max_output_hard) via SshPool.run's drain instead of the
            # cap=None unbounded path. Returned bytes are byte-identical after
            # the max_output truncation; only relay memory is bounded.
            work=lambda: app.ssh.run(
                host,
                command,
                timeout=t,
                connect_kwargs=ck,
                max_output_bytes=app.settings.max_output_hard,
            ),
        )

    @mcp.tool()
    async def ssh_spawn(
        host: str,
        command: str = "",
        cols: int = 120,
        rows: int = 40,
        user: str = "",
        port: int = 0,
        key_path: str = "",
        known_hosts: str = "",
        jump: str = "",
        ctx: Context | None = None,
    ) -> str:
        """Open a persistent interactive PTY on a remote host; returns a session id.

        Use when the remote work is interactive or long-lived and needs a real
        TTY (a remote shell, a REPL, a program that prompts). Drive the returned
        id with ``session_send`` / ``session_recv``, exactly like a local
        ``shell_spawn`` session. For a one-shot remote command, use ``ssh_exec``
        instead.
        """
        ck = app.connect_kwargs(user, port, key_path, known_hosts, jump)

        async def _work() -> tuple[str, int | None]:
            transport = await app.ssh.open_process(
                host, command=command, cols=cols, rows=rows, connect_kwargs=ck
            )
            sess = await app.register_session(
                kind="ssh",
                title=f"ssh {host}: {command or 'shell'}",
                transport=transport,
                cols=cols,
                rows=rows,
            )
            return (f"session {sess.id} started (ssh {host}); use session_recv/session_send", None)

        return await app.run(
            tool="ssh_spawn",
            ctx=ctx,
            audit_args={
                "host": host,
                "command": command or "shell",
                "size": f"{cols}x{rows}",
                **app.ssh_target_audit(host, user, port, key_path, jump, known_hosts),
            },
            policy_text=_policy_text_ssh_spawn(host, command, jump),
            max_output=4096,
            work=_work,
        )

    # ---- sessions ----------------------------------------------------------
    @mcp.tool()
    async def session_send(
        session_id: str, data: str, enter: bool = True, ctx: Context | None = None
    ) -> str:
        """Send input to a session (local or SSH). ``enter`` appends a newline."""

        async def _work() -> tuple[str, int | None]:
            payload = data + ("\n" if enter else "")
            await app.sessions.send(session_id, payload.encode("utf-8"))
            return (f"sent {len(payload)} bytes to {session_id}", None)

        # What reaches the audit record is decided here, before the send clears the
        # session's prompt tail. The executor and the policy still see the real text.
        audit_args: dict[str, Any] = {"session_id": session_id, "enter": enter}
        if await app.sessions.awaiting_secret(session_id):
            # Withhold the digest too: an unsalted SHA-256 of a typed password is
            # brute-forceable offline, so `hash` mode must not record one here.
            audit_args["data"] = "[REDACTED: secret prompt]"
            audit_args["data_len"] = len(data)
        elif cfg.audit_session_input == "hash":
            audit_args["data_len"] = len(data)
            audit_args["data_sha256"] = sha256_hex(data)
        else:
            audit_args["data"] = data

        return await app.run(
            tool="session_send",
            ctx=ctx,
            audit_args=audit_args,
            policy_text=_policy_text_session_send(
                data, await app.sessions.pending_input(session_id)
            ),
            max_output=2048,
            work=_work,
        )

    @mcp.tool()
    async def session_recv(
        session_id: str,
        timeout: float = 2.0,
        max_bytes: int = 65536,
        ctx: Context | None = None,
    ) -> str:
        """Read buffered/new output from a session, waiting up to ``timeout`` seconds."""
        # Clamp up front so the audited value is always finite (a bare NaN/Infinity
        # is not valid JSON for strict log shippers).
        tmo = max(0.0, min(float(timeout), 60.0))

        async def _work() -> tuple[str, int | None]:
            mb = clamp(max_bytes, 256, app.settings.max_output_hard)
            return (await app.sessions.recv(session_id, tmo, mb), None)

        return await app.run(
            tool="session_recv",
            ctx=ctx,
            audit_args={"session_id": session_id, "timeout": tmo},
            policy_text="",
            max_output=max_bytes,
            work=_work,
        )

    @mcp.tool()
    async def session_resize(
        session_id: str, cols: int, rows: int, ctx: Context | None = None
    ) -> str:
        """Resize a session's PTY."""

        async def _work() -> tuple[str, int | None]:
            c, r = clamp(cols, 1, 0xFFFF), clamp(rows, 1, 0xFFFF)
            await app.sessions.resize(session_id, c, r)
            return (f"resized {session_id} to {c}x{r}", None)

        return await app.run(
            tool="session_resize",
            ctx=ctx,
            audit_args={"session_id": session_id, "cols": cols, "rows": rows},
            policy_text="",
            max_output=512,
            work=_work,
        )

    @mcp.tool()
    async def session_kill(
        session_id: str,
        signal_name: str = "TERM",
        close: bool = True,
        ctx: Context | None = None,
    ) -> str:
        """Signal a session and (by default) close and reap it."""

        async def _work() -> tuple[str, int | None]:
            name = signal_name.strip().upper()
            if name.startswith("SIG"):
                name = name[3:]
            # Only real signals: `getattr(signal, ...)` also resolved SIG_IGN / SIG_DFL
            # (sent as signals 1 and 0) and silently fell back to TERM for a typo.
            try:
                sig = int(signal.Signals[f"SIG{name}"])
            except KeyError:
                raise RelayError(f"unknown signal: {signal_name[:32]!r}") from None
            await app.sessions.kill(session_id, sig)
            if close:
                await app.sessions.close(session_id)
                return (f"killed and closed {session_id}", None)
            return (f"sent SIG{name} to {session_id}", None)

        return await app.run(
            tool="session_kill",
            ctx=ctx,
            audit_args={"session_id": session_id, "signal": signal_name, "close": close},
            policy_text="",
            max_output=512,
            work=_work,
        )

    @mcp.tool()
    async def session_list(ctx: Context | None = None) -> str:
        """List active sessions with size, age, idle, and byte counters."""

        async def _work() -> tuple[str, int | None]:
            rows = await app.sessions.list()
            return (json.dumps(rows, indent=2) if rows else "[]", None)

        return await app.run(
            tool="session_list",
            ctx=ctx,
            audit_args={},
            policy_text="",
            max_output=65536,
            work=_work,
        )

    # ---- ssh transfer / forwarding ----------------------------------------
    @mcp.tool()
    async def ssh_upload(
        host: str,
        local_path: str,
        remote_path: str,
        recursive: bool = False,
        timeout: int = 0,
        user: str = "",
        port: int = 0,
        key_path: str = "",
        known_hosts: str = "",
        jump: str = "",
        ctx: Context | None = None,
    ) -> str:
        """Upload a file or tree to a remote host via SFTP.

        ``timeout`` caps the transfer in seconds (clamped to the server max);
        ``0`` (default) means no per-call cap, leaving only the connection
        keepalive. A transfer that exceeds the cap returns a
        ``[TIMEOUT after Ns]`` string.
        """
        ck = app.connect_kwargs(user, port, key_path, known_hosts, jump)
        t = app.clamp_timeout(timeout) if timeout > 0 else 0

        async def _work() -> tuple[str, int | None]:
            msg = await app.ssh.sftp_put(
                host, local_path, remote_path, recurse=recursive, connect_kwargs=ck, timeout=t
            )
            return (msg, None)

        return await app.run(
            tool="ssh_upload",
            ctx=ctx,
            audit_args={
                "host": host,
                "local": local_path,
                "remote": remote_path,
                "recursive": recursive,
                "timeout": t,
                **app.ssh_target_audit(host, user, port, key_path, jump, known_hosts),
            },
            policy_text=_policy_text_ssh_upload(host, local_path, remote_path, jump),
            max_output=2048,
            work=_work,
        )

    @mcp.tool()
    async def ssh_download(
        host: str,
        remote_path: str,
        local_path: str,
        recursive: bool = False,
        timeout: int = 0,
        user: str = "",
        port: int = 0,
        key_path: str = "",
        known_hosts: str = "",
        jump: str = "",
        ctx: Context | None = None,
    ) -> str:
        """Download a file or tree from a remote host via SFTP.

        ``timeout`` caps the transfer in seconds (clamped to the server max);
        ``0`` (default) means no per-call cap, leaving only the connection
        keepalive. A transfer that exceeds the cap returns a
        ``[TIMEOUT after Ns]`` string.
        """
        ck = app.connect_kwargs(user, port, key_path, known_hosts, jump)
        t = app.clamp_timeout(timeout) if timeout > 0 else 0

        async def _work() -> tuple[str, int | None]:
            msg = await app.ssh.sftp_get(
                host, remote_path, local_path, recurse=recursive, connect_kwargs=ck, timeout=t
            )
            return (msg, None)

        return await app.run(
            tool="ssh_download",
            ctx=ctx,
            audit_args={
                "host": host,
                "remote": remote_path,
                "local": local_path,
                "recursive": recursive,
                "timeout": t,
                **app.ssh_target_audit(host, user, port, key_path, jump, known_hosts),
            },
            policy_text=_policy_text_ssh_download(host, remote_path, local_path, jump),
            max_output=2048,
            work=_work,
        )

    @mcp.tool()
    async def ssh_forward(
        host: str,
        spec: str,
        user: str = "",
        port: int = 0,
        key_path: str = "",
        known_hosts: str = "",
        jump: str = "",
        ctx: Context | None = None,
    ) -> str:
        """Create a port forward.

        Spec: ``L:lport:dhost:dport`` (local), ``R:rport:dhost:dport``
        (remote), or ``D:lport`` (dynamic SOCKS).
        """
        ck = app.connect_kwargs(user, port, key_path, known_hosts, jump)

        async def _work() -> tuple[str, int | None]:
            handle = await app.ssh.add_forward(host, spec, connect_kwargs=ck)
            return (
                f"forward {handle.id} active: {handle.kind} {spec} "
                f"listening on port {handle.listen_port}",
                None,
            )

        return await app.run(
            tool="ssh_forward",
            ctx=ctx,
            audit_args={
                "host": host,
                "spec": spec,
                **app.ssh_target_audit(host, user, port, key_path, jump, known_hosts),
            },
            policy_text=_policy_text_ssh_forward(spec, host, jump),
            max_output=1024,
            work=_work,
        )

    @mcp.tool()
    async def ssh_forward_list(ctx: Context | None = None) -> str:
        """List active SSH port forwards."""

        async def _work() -> tuple[str, int | None]:
            rows = app.ssh.list_forwards()
            return (json.dumps(rows, indent=2) if rows else "[]", None)

        return await app.run(
            tool="ssh_forward_list",
            ctx=ctx,
            audit_args={},
            policy_text="",
            max_output=8192,
            work=_work,
        )

    @mcp.tool()
    async def ssh_forward_close(forward_id: str, ctx: Context | None = None) -> str:
        """Close an SSH port forward by id."""

        async def _work() -> tuple[str, int | None]:
            return (await app.ssh.close_forward(forward_id), None)

        return await app.run(
            tool="ssh_forward_close",
            ctx=ctx,
            audit_args={"forward_id": forward_id},
            policy_text="",
            max_output=512,
            work=_work,
        )

    @mcp.tool()
    async def ssh_check(hosts: str = "", timeout: int = 5, ctx: Context | None = None) -> str:
        """Probe connectivity to the given hosts (or the whole inventory)."""

        async def _work() -> tuple[str, int | None]:
            names = app.target_names(hosts)
            if not names:
                return ("[no hosts configured; pass hosts= or add an inventory]", None)
            if len(names) > _SSH_CHECK_MAX_HOSTS:
                return (
                    f"[ERROR: {len(names)} hosts exceeds the per-call cap of "
                    f"{_SSH_CHECK_MAX_HOSTS}; split into smaller batches]",
                    None,
                )
            tmo = clamp(timeout, 1, 60)
            ck = app.connect_kwargs("", 0, "", "", "", connect_timeout=tmo)
            sem = asyncio.Semaphore(_SSH_CHECK_CONCURRENCY)

            async def _probe(name: str) -> str:
                async with sem:
                    try:
                        out, code = await app.ssh.run(
                            name,
                            "echo ok",
                            timeout=tmo,
                            connect_kwargs=ck,
                            max_output_bytes=_SSH_CHECK_PER_HOST_OUTPUT_CAP,
                        )
                        ok = code == 0 and "ok" in out
                        return f"{name}: {'ok' if ok else 'UNREACHABLE'}"
                    except Exception as exc:  # noqa: BLE001
                        return f"{name}: UNREACHABLE ({exc.__class__.__name__})"

            # gather preserves input order in the result list regardless of
            # which probe finishes first.
            lines = await asyncio.gather(*(_probe(n) for n in names))
            return ("\n".join(lines), None)

        # Probing the inventory is an observation; probing an address the operator
        # never configured dials a caller-chosen host with the relay's keys, so that
        # case is at least Tier 1 (refused in `readonly`).
        requested = [h for h in hosts.replace(",", " ").split() if h]
        outside_inventory = any(not app.inventory.knows(h) for h in requested)
        return await app.run(
            tool="ssh_check",
            ctx=ctx,
            audit_args={"hosts": hosts or "inventory"},
            policy_text=_policy_text_ssh_check(hosts),
            max_output=8192,
            work=_work,
            min_tier=Tier.REVERSIBLE if outside_inventory else Tier.READ_ONLY,
            extra_notices=app.host_key_notices(app.target_names(hosts)),
        )

    @mcp.tool()
    async def ssh_fanout(
        command: str,
        hosts: str = "",
        timeout: int = 30,
        concurrency: int = 8,
        ctx: Context | None = None,
    ) -> str:
        """Run ``command`` in parallel across hosts; per-host exit codes in one JSON.

        ``hosts`` is a comma/space-separated list, or empty to fan out across
        every entry in the resolved inventory. ``concurrency`` bounds how
        many SSH connections run at once (clamped to ``[1, 32]``). Tier is
        classified from ``command`` like a regular ``ssh_exec`` so the deny
        list and ``guarded``/``readonly`` modes see the same probe text;
        ``ssh_fanout rm -rf /`` is still Tier 3 and still refused.
        """
        # Constructed once, outside _work, so app.run() sees it before
        # admitting; the tier heuristics fire identically to ssh_exec, and the
        # target hosts reach the deny list (F2).
        policy_text = _policy_text_ssh_fanout(hosts, command)

        async def _work() -> tuple[str, int | None]:
            names = app.target_names(hosts)
            if not names:
                return ("[no hosts configured; pass hosts= or add an inventory]", None)
            if len(names) > _SSH_FANOUT_MAX_HOSTS:
                return (
                    f"[ERROR: {len(names)} hosts exceeds the per-call cap of "
                    f"{_SSH_FANOUT_MAX_HOSTS}; split into smaller batches]",
                    None,
                )
            tmo = app.clamp_timeout(timeout)
            conc = clamp(concurrency, 1, 32)
            sem = asyncio.Semaphore(conc)

            # Aggregate output budget for the interior `truncate` calls. If the
            # serialized JSON exceeded `cfg.max_output`, Relay.run() would append a
            # [TRUNCATED ...] marker and the response would no longer parse. The
            # arithmetic below is conservative so that cannot happen, even at the
            # maximum host count. See review on #31.
            agg_budget = app.clamp_output(cfg.max_output)
            # Cap the echoed command so it alone cannot blow the envelope.
            command_budget = min(2048, agg_budget // 4)
            command_echo = truncate(command, command_budget)
            # Per-record reserve: record framing `{"host":"X","exit_code":N,
            # "output":"..."}` is ~50 bytes, the `truncate` marker `\n\n[TRUNCATED -
            # X bytes total, Y shown]` ~50 more, plus ~100 for JSON escape
            # expansion (quotes, newlines).
            per_record_overhead = 200
            # Top-level envelope: command echo, integer fields, array brackets, slack.
            envelope_overhead = 1024 + len(command_echo) + len(names) * per_record_overhead
            remaining = max(agg_budget - envelope_overhead, 0)
            per_host_budget = max(128, remaining // max(len(names), 1))

            ck = app.connect_kwargs("", 0, "", "", "", connect_timeout=tmo)

            async def _run_one(name: str) -> dict[str, Any]:
                async with sem:
                    try:
                        out, code = await app.ssh.run(
                            name,
                            command,
                            timeout=tmo,
                            connect_kwargs=ck,
                            max_output_bytes=per_host_budget,
                        )
                        return {
                            "host": name,
                            "exit_code": code,
                            "output": truncate(out, per_host_budget),
                        }
                    except Exception as exc:  # noqa: BLE001
                        # codex P2 on #31: bound the exception message too, or long
                        # errors from a few hosts can blow the envelope.
                        err = truncate(
                            f"[UNREACHABLE: {exc.__class__.__name__}: {exc}]",
                            per_host_budget,
                        )
                        return {
                            "host": name,
                            "exit_code": None,
                            "output": err,
                        }

            results = await asyncio.gather(*(_run_one(n) for n in names))
            payload = {
                "command": command_echo,
                "concurrency": conc,
                "timeout": tmo,
                "host_count": len(names),
                "results": results,
            }
            # Compact JSON (no indent) keeps the per-record estimate above realistic.
            return (json.dumps(payload, default=str), None)

        return await app.run(
            tool="ssh_fanout",
            ctx=ctx,
            audit_args={
                "command": command,
                # Raw input, not the resolved fallback: "hosts or 'inventory'"
                # would lose caller intent for an empty string (Copilot review on #31).
                "hosts": hosts,
                "timeout": timeout,
                "concurrency": concurrency,
            },
            policy_text=policy_text,
            max_output=app.clamp_output(cfg.max_output),
            work=_work,
            extra_notices=app.host_key_notices(app.target_names(hosts)),
            json_notices=True,  # the result is a JSON object: notices go inside it
        )

    @mcp.tool()
    async def ssh_keyscan(
        hosts: str,
        port: int = 22,
        key_types: str = "rsa,ecdsa,ed25519",
        timeout: int = 10,
        ctx: Context | None = None,
    ) -> str:
        """Fetch host public keys via ssh-keyscan (Tier 1, reversible).

        Opens caller-chosen outbound TCP connections to each host on
        ``port`` and reads their public host keys in known_hosts line
        format. Useful for pre-populating ``~/.ssh/known_hosts`` so a
        service account can run ``strict`` without a manual
        ``accept-new`` seeding pass.
        """

        async def _work() -> tuple[str, int | None]:
            # Validate every input *before* it reaches the shell.
            host_list = [h for h in hosts.replace(",", " ").split() if h]
            if not host_list:
                return ("[no hosts; pass hosts=<host>[,<host>...]]", None)
            # Bound outbound network burst: without the cap one call could send
            # thousands of SYNs to attacker-chosen destinations.
            if len(host_list) > _SSH_KEYSCAN_MAX_HOSTS:
                return (
                    f"[ERROR: {len(host_list)} hosts exceeds the per-call cap of "
                    f"{_SSH_KEYSCAN_MAX_HOSTS}; split into smaller batches]",
                    None,
                )
            for h in host_list:
                # Letters, digits, dot, dash, underscore, brackets, colon (bracketed
                # IPv6). No whitespace, shell metachars or path separators.
                if not _HOSTNAME_RE.match(h):
                    return (
                        f"[ERROR: rejected host {h!r}: must match {_HOSTNAME_RE.pattern}]",
                        None,
                    )
            if not 1 <= port <= 65535:
                return (f"[ERROR: port {port} out of range 1..65535]", None)
            type_list = [t.strip() for t in key_types.split(",") if t.strip()]
            for t in type_list:
                if t not in _ALLOWED_KEY_TYPES:
                    return (
                        f"[ERROR: rejected key type {t!r}: "
                        f"choose from {sorted(_ALLOWED_KEY_TYPES)}]",
                        None,
                    )
            if not type_list:
                return ("[ERROR: empty key_types]", None)
            tmo = clamp(timeout, 1, 60)

            # shlex.quote on every token is defence in depth after the regex: the
            # regex permits `-`, so a future loosening admitting a leading-dash
            # hostname would otherwise allow option injection. The literal `--`
            # likewise stops a leading-dash host being parsed as a flag.
            cmd_parts = [
                "ssh-keyscan",
                "-T",
                str(tmo),
                "-t",
                shlex.quote(",".join(type_list)),
                "-p",
                str(port),
                "--",
                *(shlex.quote(h) for h in host_list),
            ]
            cmd = " ".join(cmd_parts)
            # Keys go to stdout, progress/errors to stderr; merge so the operator
            # sees both. PERF-4: cap buffered output at max_output_hard, as in
            # shell_exec/shell_script; otherwise a misbehaving host could stream an
            # unbounded banner and grow relay memory across the scanned hosts.
            return await run_command(
                cmd,
                timeout=tmo,
                merge_stderr=True,
                output_cap=app.settings.max_output_hard,
            )

        return await app.run(
            tool="ssh_keyscan",
            ctx=ctx,
            audit_args={
                "hosts": hosts,
                "port": port,
                "key_types": key_types,
            },
            # The scan targets are the caller-controlled, executor-visible part,
            # so the deny list must see them (SEC-1). See _policy_text_ssh_keyscan.
            policy_text=_policy_text_ssh_keyscan(hosts),
            max_output=app.clamp_output(cfg.max_output),
            work=_work,
        )

    @mcp.tool()
    async def ssh_hosts(ctx: Context | None = None) -> str:
        """Show the resolved host inventory (ssh_config + inventory file)."""

        async def _work() -> tuple[str, int | None]:
            rows = [h.as_dict() for h in app.inventory.hosts()]
            return (json.dumps(rows, indent=2) if rows else "[]", None)

        return await app.run(
            tool="ssh_hosts",
            ctx=ctx,
            audit_args={},
            policy_text="",
            max_output=32768,
            work=_work,
        )

    @mcp.tool()
    async def server_info(ctx: Context | None = None) -> str:
        """Report version, effective limits, policy mode, and audit status."""

        async def _work() -> tuple[str, int | None]:
            uid = os.getuid()
            euid = os.geteuid()
            user = ""
            with contextlib.suppress(KeyError):
                user = pwd.getpwuid(euid).pw_name
            _seccomp_support = seccomp.platform_support()
            info = {
                "name": "relay-shell",
                "version": __version__,
                "transport": cfg.transport,
                "policy_mode": cfg.policy_mode,
                "warnings": config_warnings(cfg, euid=euid),
                "runtime": {
                    "uid": uid,
                    "euid": euid,
                    "user": user,
                    "is_root": euid == 0,
                    "sudo_binary": app.sudo_binary,
                },
                "limits": {
                    "default_timeout": cfg.default_timeout,
                    "max_timeout": cfg.max_timeout,
                    "max_output": cfg.max_output,
                    "max_output_hard": cfg.max_output_hard,
                    "max_sessions": cfg.max_sessions,
                    "max_forwards": cfg.max_forwards,
                    "max_conns": cfg.max_conns,
                    "max_input": cfg.max_input,
                },
                "audit": {
                    "path": app.audit.path,
                    "session_input": cfg.audit_session_input,
                    "degraded": app.audit.degraded,
                    "format": app.audit.format,
                    "chain": app.audit.chain,
                    "intent": cfg.audit_intent,
                },
                "confirm": {
                    "tier3": cfg.confirm_tier3,
                    "ttl": cfg.confirm_ttl,
                    "pending": app.broker.pending() if app.broker is not None else 0,
                },
                "seccomp": {
                    "notify": cfg.seccomp_notify,
                    "supported": _seccomp_support.ok,
                    "reason": _seccomp_support.reason,
                    "cap": cfg.seccomp_notify_cap,
                    "filter_version": seccomp.SECCOMP_FILTER_VERSION,
                },
                "ssh": {
                    "known_hosts_default": cfg.ssh_known_hosts,
                    "allow_weaker_known_hosts": cfg.ssh_allow_weaker_known_hosts,
                    "inventory_hosts": len(app.inventory.hosts()),
                    "ssh_config": app.inventory.ssh_config_file,
                    "connect_timeout": cfg.ssh_connect_timeout,
                    "keepalive": cfg.ssh_keepalive,
                    "idle_timeout": cfg.ssh_idle_timeout,
                },
            }
            return (json.dumps(info, indent=2), None)

        return await app.run(
            tool="server_info",
            ctx=ctx,
            audit_args={},
            policy_text="",
            max_output=8192,
            work=_work,
        )

    @mcp.tool()
    async def operation_confirm(token: str, ctx: Context | None = None) -> str:
        """Arm a Tier-3 confirmation token, then re-issue the original call.

        Second step of the opt-in confirmation flow (ADR 0009). When the
        confirmation broker is enabled (``RELAY_SHELL_CONFIRM_TIER3``), an
        irreversible (Tier 3) call first returns a token instead of running;
        pass that token here to arm it, then re-issue the *exact* same call to
        execute it. Tokens are single-use and expire after
        ``RELAY_SHELL_CONFIRM_TTL`` seconds. When the broker is disabled this
        reports that and changes nothing.
        """

        # The arming client must be the one the token was issued to (A14-C10b); the same
        # verified identity the audit record carries, never request metadata.
        _, arming_client = _ctx_ids(ctx)

        async def _work() -> tuple[str, int | None]:
            if app.broker is None:
                return (
                    "[confirmation broker disabled (RELAY_SHELL_CONFIRM_TIER3 is off)]",
                    None,
                )
            if app.broker.arm(token, arming_client):
                return ("[armed: re-issue the exact Tier-3 call now to execute it]", None)
            return ("[invalid or expired confirmation token]", None)

        # Audit the arm attempt, but never log the raw capability token: a
        # non-replayable fingerprint is enough to correlate with the plan
        # record without putting a live token in the audit trail.
        fingerprint = sha256_hex(token)[:12] if token else ""
        return await app.run(
            tool="operation_confirm",
            ctx=ctx,
            audit_args={"token_sha256": fingerprint},
            policy_text="",
            max_output=1024,
            work=_work,
        )

    @mcp.tool()
    async def audit_tail(
        lines: int = 50,
        tool: str = "",
        tier: int = -1,
        denied: bool | None = None,
        ctx: Context | None = None,
    ) -> str:
        """Return recent audit-log records as JSONL (oldest first), optionally filtered.

        Scans the last ``lines`` records (clamped to ``[1, 1000]``) and returns
        those matching the optional filters: ``tool`` (exact tool name, e.g.
        ``shell_exec``; empty = any), ``tier`` (``0``..``3``; ``-1`` = any), and
        ``denied`` (``true``/``false``; unset = any). Filtering narrows *within*
        the scanned window, so widen ``lines`` to reach further back. Read-only,
        Tier 0 — an operator MCP client can triage the audit trail (only denied
        calls, only one tool) without shelling into the host. Returns the empty
        string if the log is absent/empty or nothing in the window matches.
        """
        # Clamp so a misconfigured client cannot ask for the whole log; the
        # wrapper's output budget is the second line of defence (even 1000
        # worst-case records get truncated, not sent whole).
        bounded = clamp(lines, 1, 1000)
        # Only the filters that are actually set reach the audit args, so an
        # unfiltered call records the same {"lines": N} shape as before.
        audit_args: dict[str, Any] = {"lines": bounded}
        if tool:
            audit_args["tool_filter"] = tool
        if tier >= 0:
            audit_args["tier_filter"] = tier
        if denied is not None:
            audit_args["denied_filter"] = denied

        def _read_and_filter() -> str:
            # File read is blocking; the (cheap) parse+filter rides the same
            # offload so the event loop stays free even at 1000 records.
            text = app.audit.tail(bounded)
            if not tool and tier < 0 and denied is None:
                return text  # unfiltered path is byte-identical to before
            return _filter_audit_records(text, tool, tier, denied)

        async def _work() -> tuple[str, int | None]:
            return await asyncio.to_thread(_read_and_filter), None

        return await app.run(
            tool="audit_tail",
            ctx=ctx,
            audit_args=audit_args,
            policy_text="",
            max_output=app.clamp_output(cfg.max_output),
            work=_work,
        )

    # --- /metrics (HTTP transport only) -------------------------------------
    #
    # MCPServer.custom_route bypasses the OAuth layer by design (upstream intends
    # it for health-check style endpoints). The audit log is the source of truth;
    # /metrics is for dashboards only and is firewalled by the Caddy edge in the
    # supported deployment.
    if cfg.transport == "http":
        from starlette.requests import Request
        from starlette.responses import Response

        @mcp.custom_route("/metrics", methods=["GET"], include_in_schema=False)
        async def _metrics(_request: Request) -> Response:
            body = app.metrics.render()
            return Response(
                content=body,
                media_type="text/plain; version=0.0.4; charset=utf-8",
            )

    # --- MCP resources ------------------------------------------------------
    #
    # Resources are read-only client-pulled context. They do not go through
    # Relay.run (no work to admit, tier or time out), but each read is audited
    # (tier 0, tool name prefixed "resource:") so the operator sees what context
    # the model pulls in.
    #
    # Resource reads also bypass `Policy.check`: `RELAY_SHELL_POLICY_DENY` and
    # `RELAY_SHELL_POLICY_MODE=readonly|guarded` do not apply to resource URIs.
    # Deliberate: the data is the same `ssh_hosts` / `ssh_config_file` metadata a
    # Tier-0 tool returns in any mode (SECURITY.md §Scope). To refuse a specific
    # resource, route it through `Relay.run` with a `policy_text` naming it.
    #
    # The audit `tool` field is stable per resource (no user-controlled data); the
    # host parameter of the templated resource goes in `args`, so `redact_args`
    # can scrub embedded secrets and tool-name cardinality stays bounded.

    def _audit_resource_read(name: str, body: str, args: dict[str, Any] | None = None) -> None:
        tool_label = f"resource:{name}"
        app.audit.record(
            tool=tool_label,
            args=redact_args(args or {}),
            output=body,
            exit_code=None,
            tier=0,
        )
        # Same counter and label set as tool calls, so a flood of resource reads
        # shows on /metrics. Cardinality is bounded by the three resource names
        # (resource:inventory, resource:inventory_host, resource:ssh-config).
        app.metrics.inc_tool_call(
            tool=tool_label,
            tier=0,
            mode=app.settings.policy_mode,
            outcome="ok",
        )

    # Bound every resource payload to the cap tools get via `Relay.run`; a huge
    # inventory would otherwise yield arbitrarily large payloads and hashing work.
    _resource_cap = app.clamp_output(cfg.max_output)

    @mcp.resource(
        "relay-shell://inventory",
        name="inventory",
        title="Host inventory",
        description=(
            "Flat list of all hosts resolved from ~/.ssh/config and the optional "
            "RELAY_SHELL_INVENTORY file, as a JSON array of host specs. Same "
            "data shape as the ssh_hosts tool. Bodies are bounded by the same "
            "max_output cap as tools; oversized responses get a [TRUNCATED ...] "
            "marker appended, the same way tools do."
        ),
        mime_type="application/json",
    )
    def _resource_inventory() -> str:
        body = json.dumps([h.as_dict() for h in app.inventory.hosts()], default=str)
        body = truncate(body, _resource_cap)
        _audit_resource_read("inventory", body)
        return body

    @mcp.resource(
        "relay-shell://inventory/{host}",
        name="inventory_host",
        title="Single host spec",
        description=(
            "Resolved spec for one inventory entry (or a passthrough spec the "
            "ssh layer would accept) as JSON. Audit records this read as "
            'tool="resource:inventory_host" with the host in args (so redaction '
            "runs and the tool-name cardinality stays bounded)."
        ),
        mime_type="application/json",
    )
    def _resource_inventory_host(host: str) -> str:
        spec = app.inventory.resolve(host).as_dict()
        body = json.dumps(spec, default=str)
        body = truncate(body, _resource_cap)
        _audit_resource_read("inventory_host", body, args={"host": host})
        return body

    @mcp.resource(
        "relay-shell://ssh-config",
        name="ssh_config",
        title="SSH config metadata",
        description=(
            "Path to the active ssh_config and the sorted list of non-wildcard "
            "Host aliases declared in it, as JSON. Inventory overrides do not "
            "suppress aliases - any name the active ssh_config declares appears "
            "here, so a client gets an accurate view of what the file contains."
        ),
        mime_type="application/json",
    )
    def _resource_ssh_config() -> str:
        payload = {
            "path": app.inventory.ssh_config_file,
            "aliases": app.inventory.ssh_config_aliases(),
        }
        body = json.dumps(payload, default=str)
        body = truncate(body, _resource_cap)
        _audit_resource_read("ssh-config", body)
        return body

    # --- MCP prompts --------------------------------------------------------
    #
    # A prompt is client-pullable guidance: the detailed "when to use which tool"
    # text (the `instructions` string carries the concise version). Like a
    # resource read it does not flow through `Relay.run`, but a fetch is a
    # model-context pull, so it is audited (tier 0, tool="prompt:<name>") to keep
    # all pulled context visible to the operator. The body is bounded by the same
    # `max_output` cap as resources. See ADR 0008.
    #
    # `list_prompts` returns metadata only and never calls the function, so the
    # audit fires on `prompts/get`, not on discovery, as with resource reads.

    def _audit_prompt_read(name: str, body: str) -> None:
        tool_label = f"prompt:{name}"
        # No user-controlled arguments: args is empty and the tool label constant,
        # keeping cardinality bounded (same contract as the resource reads).
        app.audit.record(
            tool=tool_label,
            args={},
            output=body,
            exit_code=None,
            tier=0,
        )
        app.metrics.inc_tool_call(
            tool=tool_label,
            tier=0,
            mode=app.settings.policy_mode,
            outcome="ok",
        )

    @mcp.prompt(
        name="operating_guide",
        title="relay-shell operating guide",
        description=(
            "How to drive relay-shell: choosing between a one-shot command and "
            "a persistent PTY session, the spawn+session workflow, the fleet "
            "and file-transfer entry points, and the bounded, audited execution "
            "model to expect. Pull this when deciding which tool to use."
        ),
    )
    def _prompt_operating_guide() -> str:
        body = truncate(_OPERATING_GUIDE, _resource_cap)
        _audit_prompt_read("operating_guide", body)
        return body

    # Expose the Relay so `__main__` can wire graceful shutdown (sessions + ssh
    # pool teardown) and `--check-config` can read the audit degraded flag
    # without a second Relay (which would open the audit log twice and reload the
    # inventory). Not public API; stable within the package.
    mcp.relay = app  # type: ignore[attr-defined]
    return mcp


_INSTRUCTIONS = """\
relay-shell - shell and SSH operations.

Choosing a tool:
- A command that runs and exits on its own -> shell_exec (local) or
  ssh_exec (remote). Several statements or a non-bash interpreter ->
  shell_script.
- Interactive or long-lived work that needs a real TTY (a REPL, a TUI, a
  pager, a password prompt, a job you watch) -> shell_spawn (local) or
  ssh_spawn (remote). These return a session id; drive it with session_send
  and session_recv, and manage it with session_resize, session_kill, and
  session_list. Spawning and the session tools are one workflow, not
  alternatives: the spawn creates the PTY, the session tools drive it.
- Move files with ssh_upload / ssh_download; tunnel ports with ssh_forward
  (inspect and close via ssh_forward_list / ssh_forward_close).
- Before fleet work, list hosts with ssh_hosts and probe them with
  ssh_check; run one command across many hosts with ssh_fanout; seed
  known_hosts with ssh_keyscan.

Diagnostics: server_info reports limits and policy mode; audit_tail returns
recent audit records as JSONL, optionally filtered by tool / tier / denied.

Every call is tier-classified, bounded (timeout + output caps), and appended
to an append-only audit log (output is hashed, never stored). When the
optional Tier-3 confirmation broker is enabled, an irreversible command
returns a token first; arm it with operation_confirm and re-issue the same
call to execute it.
"""


# Detailed operating guide served by the `operating_guide` MCP prompt. The
# `_INSTRUCTIONS` string above is the concise version handed to every client at
# initialize; this is the longer, client-pullable form (ADR 0008).
_OPERATING_GUIDE = """\
relay-shell operating guide
===========================

relay-shell exposes local shell and SSH operations as MCP tools. Every call is
classified into a tier, bounded by a timeout and an output cap, and appended to
an append-only audit log (the output body is hashed, never stored). Tools never
raise into the transport; failures come back as bounded strings.

Choosing a tool
---------------
- A command that runs and exits on its own -> shell_exec (local) or
  ssh_exec (remote). This is the one-shot, non-interactive path.
- Several statements, or a non-bash interpreter (sh/python) -> shell_script.
- Interactive or long-lived work that needs a real TTY - a REPL or TUI, a
  pager, a program that prompts (including a sudo password), or a job you
  start and watch -> shell_spawn (local) or ssh_spawn (remote). These return a
  session id.
- One command across many hosts at once -> ssh_fanout.

Spawn and sessions are one workflow, not alternatives
-----------------------------------------------------
shell_spawn / ssh_spawn create a PTY and return a session id; the session
tools then drive that id:
  session_send   - send input (enter=true appends a newline)
  session_recv   - read new/buffered output, waiting up to timeout
  session_resize - resize the PTY (cols x rows)
  session_kill   - signal and (default) reap the session
  session_list   - list active sessions with size/age/idle counters
A typical loop:
  id = shell_spawn(command="/bin/bash")
  session_send(id, "kubectl get pods")
  session_recv(id, timeout=3)
  session_kill(id)

Working with a fleet
--------------------
- ssh_hosts    list the resolved inventory (~/.ssh/config + the optional
               inventory file).
- ssh_check    probe connectivity (whole inventory, or a host list).
- ssh_fanout   run one command across many hosts; per-host exit codes in one
               JSON object.
- ssh_keyscan  fetch host public keys to pre-populate known_hosts so a service
               account can run the strict known-hosts mode unattended.
A host is an inventory/ssh_config alias or user@host. known_hosts is
strict | accept-new | ignore.

Moving data and ports
---------------------
- ssh_upload / ssh_download   SFTP transfer (recursive supported).
- ssh_forward                 local (L), remote (R), or dynamic SOCKS (D)
                              forward; ssh_forward_list / ssh_forward_close
                              inspect and close active forwards.

Diagnostics
-----------
- server_info  version, effective limits, policy mode, audit path and state.
- audit_tail   recent audit records as JSONL (read-only); optional filters
               tool / tier / denied triage the scanned window.

Confirming an irreversible operation (opt-in)
---------------------------------------------
When the deployment enables the Tier-3 confirmation broker
(RELAY_SHELL_CONFIRM_TIER3), an irreversible command (e.g. rm -rf, mkfs)
does not run on first request: it returns [CONFIRM REQUIRED tier 3 ... token="..."].
Call operation_confirm(token="...") to arm it, then re-issue the exact same
call to execute it. Tokens are single-use and expire. When the broker is off
(the default) this never triggers.

What a result can look like
---------------------------
- [exit N] followed by output             a command that completed.
- [DENIED tier N (NAME): reason]          refused by policy (depends on
                                          RELAY_SHELL_POLICY_MODE and the
                                          deny/allow lists).
- [NOTICE ...]                            trailing line on a call that ran as
                                          Tier 2/3 or with host-key checking off:
                                          what is unsafe about it. The classifier is a
                                          heuristic; a call without a notice is not
                                          thereby safe.
- [TIMEOUT after Ns]                      exceeded the clamped timeout. For SSH
                                          the text adds "outcome unknown": verify
                                          the remote state before retrying.
- [ERROR: ExcType: message]               any other failure, contained.
- [TRUNCATED - N bytes total, M shown]    output exceeded the budget.
"""
