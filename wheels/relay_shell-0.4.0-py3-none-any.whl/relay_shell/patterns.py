"""Compiled, version-pinned regex tables for the redaction and policy layers.

Keeping the tables here makes "added a pattern" a one-file diff that a security
reviewer can read apart from :mod:`relay_shell.redaction` and
:mod:`relay_shell.policy`.

Three pattern families are exported:

* :data:`REDACTION_PREFIX_PATTERNS` - structure-preserving redactions: keep
  the non-secret prefix, replace the value with :data:`REDACTION_PLACEHOLDER`.
* :data:`REDACTION_PATTERNS` - whole-match redactions: the entire match
  collapses to :data:`REDACTION_PLACEHOLDER`.
* :data:`TIER2_PATTERN`, :data:`TIER3_PATTERN`, :data:`PRIV_ESC_PATTERN` -
  tier-classification heuristics consumed by :func:`relay_shell.policy.classify`.

:data:`MYSQL_FAMILY_CLI_PATTERN` gates :data:`MYSQL_COMPACT_PASSWORD_PATTERN`
(``-p<value>`` short-form passwords) to argument strings that contain a MySQL
CLI. :data:`URL_CREDS_PATTERN` handles ``://user:pass@host`` URL embeddings.

:data:`PATTERNS_VERSION` is a monotonic counter. Bump it on any semantic
change to a pattern (added, widened, narrowed, or removed); audit consumers
read it to detect a change in the classification or redaction surface.
"""

from __future__ import annotations

import re

__all__ = [
    "COMMAND_SCOPED_PREFIX_PATTERNS",
    "LINE_CONTINUATION_PATTERN",
    "MYSQL_COMPACT_PASSWORD_PATTERN",
    "MYSQL_FAMILY_CLI_PATTERN",
    "PATTERNS_VERSION",
    "PRIV_ESC_EVAL_HINT",
    "PRIV_ESC_PATTERN",
    "PRIV_ESC_READER_SEGMENT",
    "REDACTION_PATTERNS",
    "REDACTION_PLACEHOLDER",
    "REDACTION_PREFIX_PATTERNS",
    "SECRET_PROMPT_PATTERN",
    "TIER2_PATTERN",
    "TIER3_PATTERN",
    "URL_CREDS_PATTERN",
    "URL_TOKEN_USERINFO_PATTERN",
]

# Bump on any semantic change to a pattern (added / widened / narrowed /
# removed). v1: initial extraction from redaction.py + policy.py.
# v2: Authorization-header value widened to handle three shapes (bare
#     HTTP, quoted CLI flag, JSON dict literal) and to consume past the
#     first comma so AWS SigV4 / Digest challenge-response schemes do
#     not leak the trailing Signature/response field.
# v3: Authorization-header bare form no longer consumes arbitrary shell
#     control operators; this preserves audit fidelity for command-style
#     input while keeping quoted/JSON and comma-separated auth schemes.
# v4: REDACTION_PATTERNS gained the common structurally-anchored provider
#     secret shapes that the prefix patterns miss when a secret arrives
#     bare (in a JSON body, a log line, or a flag not in the CLI list):
#     Google API key (AIza), Google OAuth access token (ya29.), Stripe
#     secret/restricted keys (sk_/rk_ live/test/prod), GitLab PAT
#     (glpat-), npm token (npm_), PyPI upload token (pypi-AgE...), and
#     JWTs (ey<hdr>.ey<payload>.<sig>). The OpenAI `sk-` shape was
#     widened to also cover the project/service prefixes
#     (sk-proj-/sk-svcacct-/sk-admin-, with URL-safe tails). Anchors track
#     the canonical secret-scanning rulesets (gitleaks / GitHub secret
#     scanning); every body runs unbounded from its length floor and admits
#     the token's full alphabet (ya29 dots, OpenAI URL-safe separators) so a
#     match always collapses the *whole* token rather than leaving a tail.
# v5: REDACTION_PATTERNS gained Anthropic API keys (`sk-ant-...`) and
#     HuggingFace user access tokens (`hf_...`) — both high-likelihood in an
#     AI-infrastructure tool's command arguments and previously uncovered (the
#     `sk-ant-` hyphens break the bare `sk-<alnum>` run; `hf_` had no rule).
#     Whole-match collapses anchored on prefix + length floor like the rest
#     (audit pass 2026-06-21, SEC-4).
# v6: adversarial-audit fixes (2026-06-21 red-team pass).
#     - The `key=value` redaction prefix no longer requires a leading `\b`:
#       in compound names (`DB_PASSWORD=`, `APP_SECRET=`, `API_TOKEN=`) the
#       keyword is preceded by `_` (a word char) so `\b` never fired and the
#       value leaked to the audit log (RED-1). The trailing `\s*[:=]\s*\S+`
#       still gates it to assignment shapes, so removing `\b` does not
#       over-match plain words.
#     - TIER2/TIER3 classification anchors switched from `\b` to `(?<![\w])`
#       so the alternatives that start with a non-word char (`>`/`/`/`:` —
#       device-write redirects, `>/etc/`, the fork bomb) actually fire instead
#       of being dead code (POL-1).
#     - The PEM block matcher's `.*?` is now length-bounded to stop O(n²)
#       backtracking on many unterminated BEGIN markers (ReDoS on the audit
#       path, RED-2).
# v7: redaction coverage additions (2026-06-21 adversarial follow-up, RED-3).
#     New structure-preserving prefixes: AWS `*_SECRET_ACCESS_KEY=` (the
#     keyword is mid-name, so the generic `secret=` rule never fired —
#     anchored on the full `secret_access_key` phrase for FP control); Azure
#     connection-string `AccountKey=` / `SharedAccessKey=`; and Azure SAS
#     `?…&sig=<urlencoded>`. New whole-match: Slack incoming-webhook URLs
#     (`https://hooks.slack.com/services/T…/B…/…`; distinct from the `xox*`
#     token rule). GCP service-account creds need no new rule — their only
#     secret is the `private_key` PEM block, already collapsed by the PEM rule
#     above (it matches a JSON-embedded block with escaped `\n` too).
# v8: 2026-07-15 adversarial pass. RED-6: the generic keyword rule and the AWS
#     `secret_access_key` rule gained a quote-tolerant separator (`["']?` each
#     side) + a quoted-value terminator, so the JSON-quoted-key shape
#     (`"password": "x"`, `"AWS_SECRET_ACCESS_KEY": "x"`) is redacted — it was
#     leaking verbatim to the audit log (only the Authorization rule had been
#     quote-tolerant). Unquoted cases stay byte-identical (the `\S+` fallback).
#     RED-7: TIER3_PATTERN gained a long-option `rm` alternative
#     (`rm --recursive|--force|--no-preserve-root`); the short-flag-only
#     alternatives under-classified `rm --force` below Tier 3.
# v9: 2026-07-15 redaction review. RED-8: the CLI-flag rule's quoted-value
#     branches (`--password="..."` / `'...'`) required a closing quote and were
#     length-unbounded, so a quoted secret longer than the redaction scan window
#     (`_scrub_str`'s `max_len + 16 KiB`) lost its closing quote to truncation:
#     the quoted branch could not match and the greedy bare fallback stopped at
#     the first internal space, leaking the value's tail into the length-bounded
#     audit record (a P1 scan-window regression; full-string redaction still
#     caught it). Added unterminated-quote fallback branches that consume to
#     end-of-line, so a truncated/malformed quoted value still collapses whole.
#     Well-formed quoted values are byte-identical (the terminated branch is
#     tried first).
# v10: 2026-07-15 Windows/PowerShell-7 support (ADR 0011, WIN-1). TIER3_PATTERN /
#      TIER2_PATTERN / PRIV_ESC_PATTERN gained Windows + pwsh alternatives so
#      destructive PowerShell cmdlets and cmd.exe verbs on a Windows OpenSSH
#      target classify at the right tier instead of falling through to Tier 1
#      (which escaped `guarded`/`readonly` mode and the ADR 0009 broker). Pure
#      additions — POSIX matching is byte-identical; the bounded-gap rules
#      (`Remove-Item … -Recurse`, `del … /s`, `format … C:`) mirror the RED-7
#      `{0,N}?` ReDoS ceiling. Classification stays heuristic: PowerShell
#      parameter abbreviation / aliases / pipeline-delete forms can still evade
#      it (documented in ADR 0011), so the deny list + modes remain the hard
#      controls.
# v11: 2026-07-15 Windows/pwsh redaction (ADR 0011 increment C, WIN-1). Added
#      `credential` to the generic keyword rule and the CLI-flag rule (covers
#      `-Credential x`, `credential=x`, `"credential":"x"`), and a dedicated
#      `ConvertTo-SecureString` rule that redacts an inline plaintext operand
#      (`ConvertTo-SecureString 'P@ss' -AsPlainText -Force`) while leaving a
#      `$var` handle or a bare switch untouched. Keeps existing keyword behavior
#      byte-identical (pure additions).
# v12: 2026-10-04 audit pass, redaction gaps (M1; every case reproduced against
#      v11). (a) a quoted keyword value with spaces (`PASSWORD="a b c"`,
#      `{"password": "a b c"}`) leaked every word after the first: a quote-aware
#      rule now consumes to the matching closing quote. (b) the CLI-flag rule only
#      matched a bare keyword, so `--client-secret V`, `--access-token V`,
#      `--auth-token V`, `--passphrase V`, `--secret-access-key V` leaked when
#      space-separated: the flag name may now carry a hyphenated prefix and ends in
#      the keyword (`--token-url`, `--password-stdin` and `--no-password` are still
#      not secrets). (c) new command-scoped rules for `curl -u user:pass`,
#      `sshpass -p`, `docker login -p` and `openssl -pass pass:`. (d) a URL
#      password containing `@` leaked its tail; the credential run now extends to
#      the last `@` before the path. Pure additions or widenings of redaction;
#      tier classification is unchanged. (e) SECRET_PROMPT_PATTERN lets the session
#      layer withhold input typed at a password prompt from the audit record.
# v13: 2026-10-04 audit pass, tier classification (M2; every case reproduced
#      against v12). Over-classification: read-only commands that merely *named* a
#      destructive word reached Tier 3 (`smartctl -a /dev/sda`, `lsblk /dev/sda`,
#      `fdisk -l`, `git log --grep=reboot`, `journalctl -u shutdown.target`, `echo
#      'reboot required'`, `ip link show | grep down`, `cat /etc/passwd | head`),
#      which refused them in guarded/readonly and forced a confirm round trip under
#      the Tier-3 broker. The bare `/dev/sd[a-z]` rule is gone (writes to a block
#      device are still caught via `of=`, `>` and `tee`, now for nvme/vd/xvd/mmcblk
#      too); `reboot|shutdown|halt|poweroff`, `init 0|6` and `passwd <arg>` match
#      only in command position (`_CMD`); `ip link` needs `set ... down`; the
#      partitioners exempt their listing flags. Under-classification: `curl|wget ...
#      | sh` and friends (Tier 2); `find -delete` / `-exec rm`, `zpool|zfs destroy`,
#      `lvremove|vgremove|pvremove`, `blkdiscard`, `parted`, `mdadm --stop`,
#      `cryptsetup luksFormat|erase`, `nvme format`, `terraform|tofu|pulumi destroy`,
#      `systemctl reboot|poweroff`, `git push -f`, a write to /proc/sysrq-trigger
#      (Tier 3); `kill -9`, `pkill`, `killall`, `truncate`, `docker|podman system|
#      volume|image|container|network prune|rm`, `terraform|tofu apply`, `git clean
#      -f`, `setenforce` (Tier 2). Classification stays heuristic (ADR 0003).
# v15: 2026-10-14 audit follow-up (A14-C3b; reproduced against v14). An unquoted
#      redaction value ran on past a shell control operator, so a destructive command
#      glued to a keyword assignment vanished from the audit record
#      (`token=a;rm -rf /srv` was recorded as `token=[REDACTED] -rf /srv`). The
#      keyword, AWS, CLI-flag, `ConvertTo-SecureString`, `curl -u`, `sshpass`,
#      `docker login`, `openssl -pass` and MySQL compact `-p` values now stop at an
#      unquoted `;`, `&`, `&&`, `|` or `||` and keep an escaped one; a keyword value
#      closed by a quote with no whitespace between (`echo 'DB_PASSWORD=ab;cd'`) is
#      still consumed whole. Behaviour without those characters is unchanged.
#      Accepted limit: an unquoted secret that really contains one of them is cut at
#      the first, leaving its tail visible (an unquoted `;` cannot be part of a shell
#      word, and a quoted secret is handled by the quote-aware rules).
# v16: 2026-10-14 audit follow-up (A14-C8b redaction, A14-C9 classification; every case
#      reproduced against v15). Redaction: `password := X` and `password => X` (the
#      separator ate only the `:`/`=` and left the value), an unterminated PEM private-key
#      block (header plus base64 body now collapses to the end of the key material),
#      `https://TOKEN@host` user-info without a colon (web schemes, 12+ characters), and
#      secret flags of `aws configure set`, `redis-cli -a/--pass`, `unzip|zip -P` and
#      `ldap* -w`. Classification: Tier 3 for `redis-cli FLUSHALL|FLUSHDB`; Tier 2 for
#      `systemctl start|enable|reload|...` (with global flags), `useradd`/`usermod`/
#      `groupadd`/..., `iptables -A/-I/-D/...`, `nft add/delete/...`, `firewall-cmd
#      --add/--permanent/...`, `kubectl exec|drain|cordon|patch|edit|create|...` (after
#      global flags), `redis-cli shutdown|config set`, `docker-compose`, and writes by
#      `>`/`>>`/`tee` to `~/.ssh/`, `authorized_keys`, shell rc files, `sudoers`, /root,
#      /boot, /usr, /bin, /sbin, /lib*, /opt, /srv, /sys, /var/{spool,lib,www}. Under-
#      classification closed: `rm \<newline>-rf` (line continuations are removed first),
#      `sudo -u root reboot`, `nice -n 10 reboot`, `timeout 5 reboot` (wrappers with
#      arguments). Over-classification closed: `crontab -l`, `docker compose ps|logs|...`
#      and `grep sudo /var/log/auth.log` / `man sudo` / `echo sudo` (a privilege wrapper
#      named by a read-only command is data). Classification stays heuristic (ADR 0003).
PATTERNS_VERSION = "16"

REDACTION_PLACEHOLDER = "[REDACTED]"


# --- Redaction: structure-preserving (keep the prefix, replace the value) ---

# Unquoted secret value (v15). In a shell command line an unquoted `;`, `&&`, `||`, `|`
# or `&` ends the word, so a value that ran on past one (`token=a;rm -rf /srv`) hid the
# next command from the audit record. The value now stops at those characters and keeps
# an escaped one (`ab\;cd`). Exception: a value that is closed by a quote with no
# whitespace in between (`echo 'DB_PASSWORD=ab;cd'`) sits inside a quoted string, where
# the operator is data, so it is still consumed whole. The bounded possessive run keeps
# the lookahead linear. Accepted limit: an unquoted secret that really contains one of
# these characters is cut at the first one and its tail stays visible.
_VALUE_RUN = r"""(?:[^\s"'\r\n]{1,256}+(?=["'])|(?:\\[;&|]|[^\s"'\r\n;&|])+)"""

REDACTION_PREFIX_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    # Authorization / Proxy-Authorization header value, in three shapes:
    #
    #   1. Bare HTTP header  ->  `Authorization: Bearer X`
    #      Value runs until a line break or shell control operator.
    #   2. Quoted CLI flag    ->  `-H "Authorization: Bearer X"`
    #      Value stops at the surrounding closing quote.
    #   3. JSON dict literal  ->  `{"Authorization": "Bearer X"}`
    #      The optional `["']?` in the prefix spans the quote-colon-quote
    #      transition; the value runs to the closing inner quote.
    #
    # The terminator set deliberately excludes `,`: AWS Signature v4
    # (`Credential=..., SignedHeaders=..., Signature=<hex>`) and other
    # comma-separated schemes put the secret (the Signature) AFTER a comma.
    # The trade-off is that `Authorization: ..., otherfield=val` over-scrubs
    # `otherfield=val`: audit-fidelity loss, not a leak.
    (
        re.compile(
            r"(?i)\b(?P<prefix>(?:proxy-)?authorization[\"']?\s*[:=]\s*[\"']?)"
            r"(?:"
            r"[^\"'\r\n]+(?=[\"'])"
            r"|[^\r\n\"']+?(?=(?:;\s|\s;|\s(?:&&|\|\||\|)\s|[\r\n]|$))"
            r")"
        ),
        r"\g<prefix>[REDACTED]",
    ),
    # Bearer <token>
    (
        re.compile(r"(?i)\b(?P<prefix>bearer\s+)[A-Za-z0-9._\-]+"),
        r"\g<prefix>[REDACTED]",
    ),
    # Quoted keyword value (v12): `PASSWORD="two words"`, `{"password": "a b c"}`,
    # `PGPASSWORD='a b'`. The generic rule below stops at whitespace and would
    # leak every word after the first. This rule runs first and consumes up to
    # the matching closing quote (escape-aware; the quote is preserved). The
    # body is deliberately NOT length-bounded: a bound would collapse an
    # over-long value to the short placeholder and shift the unconsumed tail
    # into the kept prefix of a truncated audit record (the hazard in the
    # redaction module's P1 note). Its two alternatives are disjoint, so it is
    # linear, and an unterminated or window-truncated value collapses to
    # end-of-line instead of leaking its tail.
    (
        re.compile(
            r"(?i)(?P<prefix>(?:api[_-]?key"
            r"|(?:secret|private|access|signing|encryption|master)[_-]?key(?:[_-]?base)?"
            r"|secret|token|password|passwd|pwd|credential)"
            r"[\"']?\s*(?::=|=>|[:=])\s*(?P<q>[\"']))"
            r"(?:\\.|(?!(?P=q))[^\\\r\n])*"
        ),
        r"\g<prefix>[REDACTED]",
    ),
    # token=... / api[_-]?key=... / password: ...  (also the JSON-quoted-key
    # shape `"password": "x"`). The separator tolerates an optional quote on
    # either side (`["']?`), mirroring the Authorization rule, so `"password"`
    # (a `"` between the keyword and the `:`) still anchors (RED-6). The value
    # is `_VALUE_RUN`: a non-space, non-quote run that ends at the closing
    # quote (preserved) in the JSON shape, keeps single-token behaviour for the
    # unquoted `password=x` / `token: x` forms, and stops at an unquoted shell
    # control operator (v15). Linear: the one lookahead is behind a possessive
    # run bounded at 256 characters that never crosses whitespace, unlike a
    # `[^"'\r\n]+(?=["'])` form, which is O(n²) when the prefix recurs across a
    # large quote-free argument (a ReDoS on the sync audit path).
    (
        re.compile(
            r"(?i)(?P<prefix>(?:api[_-]?key"
            r"|(?:secret|private|access|signing|encryption|master)[_-]?key(?:[_-]?base)?"
            r"|secret|token|password|passwd|pwd|credential)"
            r"[\"']?\s*(?::=|=>|[:=])\s*[\"']?)" + _VALUE_RUN
        ),
        r"\g<prefix>[REDACTED]",
    ),
    # AWS secret access key assignment (RED-3). `secret` sits mid-name in
    # `AWS_SECRET_ACCESS_KEY=`, so the generic `secret=` rule never fires.
    # Anchored on the full `secret[_-]?access[_-]?key` phrase so that
    # `SECRET_ACCESS_KEY_PATH=/x` is not over-scrubbed. Quote-tolerant like the
    # generic rule (`"AWS_SECRET_ACCESS_KEY": "x"`, RED-6). The AWS secret has
    # no whole-match fallback, so this rule is its only protection.
    (
        re.compile(
            r"(?i)(?P<prefix>(?:aws[_-]?)?secret[_-]?access[_-]?key"
            r"[\"']?\s*(?::=|=>|[:=])\s*[\"']?)" + _VALUE_RUN
        ),
        r"\g<prefix>[REDACTED]",
    ),
    # Azure connection-string keys (RED-3): `AccountKey=<base64>` (Storage) and
    # `SharedAccessKey=<base64>` (Service Bus / Event Hubs). The value runs to
    # the `;` segment separator (or whitespace/quote), preserving the rest of
    # the connection string.
    (
        re.compile(r"(?i)(?P<prefix>(?:account|sharedaccess)key\s*=\s*)[^;\s\"']+"),
        r"\g<prefix>[REDACTED]",
    ),
    # Azure SAS token signature (RED-3): the `sig=` query parameter is the HMAC
    # that authorizes the URL. Anchored on a leading `?`/`&` (so `design=` and
    # `sign=` cannot match) and a 20+ char url-encoded base64 body.
    (
        re.compile(r"(?i)(?P<prefix>[?&]sig=)[A-Za-z0-9%/+]{20,}"),
        r"\g<prefix>[REDACTED]",
    ),
    # CLI-style flags: ``--password value``, ``--token=value``,
    # ``--api-key "two words"``, ``--password top\ secret``. See the
    # docstring of :mod:`relay_shell.redaction` for scope and the reasoning
    # around interactive flags / dash-prefixed values.
    #
    # The leading ``(?<![A-Za-z])`` keeps the dash from binding to the tail of a
    # PowerShell ``Verb-Noun`` cmdlet (``Get-Credential``, ``Get-Secret``), which
    # takes no inline secret and would otherwise over-scrub the *next* token. A
    # real secret flag is preceded by whitespace, start, ``=`` or a quote, never
    # a letter, so the guard does not reduce true redaction (WIN-1 / ADR 0011
    # increment C).
    (
        re.compile(
            r"""(?ix)
            (?P<prefix>
                (?<![A-Za-z])
                --?(?!(?:no|ask|prompt|skip|use|with|show|hide)[-_])
                (?:[A-Za-z0-9]+[-_]){0,6}
                (?:password|passwd|pwd|passphrase|secret|token|api[_-]?key|credentials?
                  |secret[_-]?key|secret[_-]?access[_-]?key)
                [=\ \t]+
            )
            (?:
                "(?:[^"\\]|\\.)*"        # double-quoted, escape-aware
              | '(?:[^'\\]|\\.)*'        # single-quoted, escape-aware
              | "[^\r\n]*                # RED-8: unterminated double-quote — the
                                        # closing quote is missing (a malformed arg)
                                        # or truncated out of the redaction scan
                                        # window (_scrub_str). Consume to end-of-line
                                        # so a long quoted secret whose close quote
                                        # falls past the window is still collapsed
                                        # instead of leaking its post-space tail.
                                        # Tried only after the terminated branch
                                        # above fails, so well-formed values are
                                        # byte-identical; audit-fidelity-loss (not a
                                        # leak) in the genuinely-unterminated case,
                                        # matching the Authorization rule's tradeoff.
              | '[^\r\n]*                # unterminated single-quote (as above)
              | (?:-(?!-)|(?!--))(?:\\.|[^\s;&|])+
                                        # bare value, treating \\<char> as one unit
                                        # (so an escaped `\;` stays inside it) and
                                        # stopping at an unquoted shell control
                                        # operator (v15); allow single-dash-prefixed
                                        # secrets (-abc) but still reject the next
                                        # long option (--host)
            )
            """,
        ),
        r"\g<prefix>[REDACTED]",
    ),
    # PowerShell inline plaintext via ``ConvertTo-SecureString`` (WIN-1 / ADR
    # 0011 increment C), the canonical pwsh idiom for a secret on the command
    # line:
    #   ConvertTo-SecureString 'P@ss' -AsPlainText -Force
    #   ConvertTo-SecureString -String "P@ss" -AsPlainText
    # The bounded ``(?:-\w+\s+){0,8}?`` skips leading switches (linear, like the
    # RED-7 rules); the operand is a quoted string or a bare token. ``(?![-$])``
    # on the bare branch leaves a switch or a `$var` (an already-encrypted
    # handle) alone, so only an inline literal is collapsed.
    (
        re.compile(
            r"""(?ix)
            (?P<prefix>convertto-securestring\s+(?:-\w+\s+){0,8}?)
            (?:
                "(?:[^"\\]|\\.)*"          # double-quoted secret
              | '(?:[^'\\]|\\.)*'          # single-quoted secret
              | (?![-$])[^\s;&|]+         # bare literal (not a switch, not a $var)
            )
            """,
        ),
        r"\g<prefix>[REDACTED]",
    ),
)


# Value of a command-scoped secret flag (v16): a terminated quote, else an unterminated
# one consumed to the end of the line (the closing quote is missing or lies beyond the
# redaction scan window, so the remainder is still secret), else a bare word that stops
# at a shell control operator. Same shape as the generic CLI-flag rule.
_SCOPED_VALUE = r"""(?:'[^']*'|"[^"]*"|'[^\r\n]*|"[^\r\n]*|[^\s;&|]+)"""

# Command-scoped credential flags (v12). Each is anchored on its command with a
# bounded gap, because the flags are overloaded (`-u` is a uid in `docker exec`,
# `-p` a port in `ssh`/`nmap`) and an unscoped rule would over-scrub. They keep
# the non-secret prefix and collapse only the secret; the bounded gaps keep
# every rule linear on adversarial input.
COMMAND_SCOPED_PREFIX_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    # curl / wget / httpie: `-u user:pass`, `--user user:pass`, `--proxy-user ...`.
    # Only the password half is collapsed; the user name is kept.
    (
        re.compile(
            r"(?i)(?P<prefix>(?<![\w-])(?:curl|wget|xh|httpie)\b[^|;&\n]{0,512}?"
            r"(?<![A-Za-z0-9-])(?:-u|--user|--proxy-user)(?:=|\s+)[\"']?[^\s:\"']+:)"
            r"[^\s\"';&|]+"
        ),
        r"\g<prefix>[REDACTED]",
    ),
    # sshpass: `sshpass -p SECRET ...` (also quoted, or glued as `-pSECRET`).
    (
        re.compile(
            r"(?i)(?P<prefix>\bsshpass\b[^|;&\n]{0,256}?(?<![A-Za-z0-9-])-p[=\s]*)" + _SCOPED_VALUE
        ),
        r"\g<prefix>[REDACTED]",
    ),
    # docker / podman / nerdctl / buildah / skopeo login: `-p SECRET`
    # (`--password` is already covered by the generic flag rule).
    (
        re.compile(
            r"(?i)(?P<prefix>\b(?:docker|podman|nerdctl|buildah|skopeo)\b[^|;&\n]{0,256}?"
            r"\blogin\b[^|;&\n]{0,256}?(?<![A-Za-z0-9-])-p[=\s]*)" + _SCOPED_VALUE
        ),
        r"\g<prefix>[REDACTED]",
    ),
    # openssl: `-pass pass:SECRET`, `-passin pass:...`, `-passout pass:...`
    # (`env:` / `file:` / `stdin` forms carry no secret and are left alone).
    (
        re.compile(r"(?i)(?P<prefix>(?<![A-Za-z0-9])-pass(?:in|out)?\s+pass:)[^\s;&|]+"),
        r"\g<prefix>[REDACTED]",
    ),
    # v16: secret flags of other CLIs, each anchored on its command because the short
    # flags are overloaded (`redis-cli -a` is auth but `-a` means "all" elsewhere,
    # `unzip -p` pipes to stdout, `ldapsearch -W` prompts and takes no value).
    #   aws configure set aws_secret_access_key|aws_session_token VALUE
    (
        re.compile(
            r"(?i)(?P<prefix>\baws\b[^|;&\n]{0,128}?\bconfigure\s+set\s+(?:--\S+\s+\S+\s+){0,3}"
            r"(?:aws_)?(?:secret_access_key|session_token)\s+)" + _SCOPED_VALUE
        ),
        r"\g<prefix>[REDACTED]",
    ),
    #   redis-cli -a PASSWORD / --pass PASSWORD
    (
        re.compile(
            r"(?i)(?P<prefix>\bredis-cli\b[^|;&\n]{0,256}?(?<![A-Za-z0-9-])(?:-a|--pass)[=\s]+)"
            + _SCOPED_VALUE
        ),
        r"\g<prefix>[REDACTED]",
    ),
    #   unzip -P PASSWORD / zip -P PASSWORD (capital P only)
    (
        re.compile(
            r"(?P<prefix>\b(?:unzip|zip)\b[^|;&\n]{0,256}?(?<![A-Za-z0-9-])-P[=\s]*)"
            + _SCOPED_VALUE
        ),
        r"\g<prefix>[REDACTED]",
    ),
    #   ldapsearch / ldapmodify / ... -w PASSWORD (lower-case w only; -W prompts)
    (
        re.compile(
            r"(?P<prefix>\bldap(?:search|modify|add|delete|compare|modrdn|passwd|whoami)\b"
            r"[^|;&\n]{0,256}?(?<![A-Za-z0-9-])-w[=\s]*)" + _SCOPED_VALUE
        ),
        r"\g<prefix>[REDACTED]",
    ),
)


# --- Redaction: whole-match (collapse the entire match to the placeholder) ---

# Provider token shapes are *structurally* anchored (a fixed prefix and a
# length floor), not on the secret's character class: the class evolves, the
# structure does not (see the redaction module docstring and runbook §6.5).
# Anchors and length bounds track the canonical secret-scanning rulesets so
# the set stays comparable to gitleaks / GitHub secret scanning:
#   https://github.com/gitleaks/gitleaks/blob/master/config/gitleaks.toml
# Whole-match collapses: a provider token has no non-secret prefix worth
# keeping. They are the safety net for secrets that arrive *bare* (a JSON
# body, a log line, a flag the CLI-flag prefix patterns do not name).
REDACTION_PATTERNS: tuple[re.Pattern[str], ...] = (
    # PEM / OpenSSH private key blocks
    re.compile(
        # Length-bound the body (a real PEM key block is < ~8 KB) so many
        # unterminated `-----BEGIN ... KEY-----` markers cannot drive O(n^2)
        # backtracking on the synchronous audit redaction path. `[\s\S]` spans
        # newlines without DOTALL.
        r"-----BEGIN [A-Z0-9 ]{0,40}PRIVATE KEY(?: BLOCK)?-----[\s\S]{0,8192}?"
        r"-----END [A-Z0-9 ]{0,40}PRIVATE KEY(?: BLOCK)?-----"
        # Unterminated (v16): no END footer within the bound, as when a key is cut
        # off by the argument cap or pasted without its footer. The audit record keeps
        # the first 500 characters, which is all key material, so collapse the header,
        # any `Proc-Type:` / `DEK-Info:` lines, and the base64 body lines that follow
        # (runs of 16+ base64 characters). Plain words such as a command on the next line
        # are not base64 runs of that length, so they stay in the record. A final body
        # line shorter than 16 characters is not consumed.
        r"|-----BEGIN [A-Z0-9 ]{0,40}PRIVATE KEY(?: BLOCK)?-----"
        r"(?:\s*[A-Za-z][A-Za-z-]*:[^\r\n]{0,200}){0,4}(?:\s*[A-Za-z0-9+/=]{16,}){0,160}",
    ),
    # GitHub: classic/fine-grained PAT, plus the gh[pousr]_ token family
    # (personal, OAuth, user-to-server, server-to-server, refresh).
    re.compile(r"\bgith(?:ub)?_pat_[A-Za-z0-9_]+"),
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{20,}"),
    # OpenAI keys. Two rules by design: the classic `sk-<alnum>` body is
    # alphanumeric only so kebab-case identifiers such as `sk-build-step` are
    # not over-scrubbed; the project / service-account / admin formats carry
    # URL-safe tails containing `_` and `-`, so their body admits those and runs
    # unbounded, else the remainder of the key would stay in the audit log.
    re.compile(r"\bsk-(?:proj|svcacct|admin)-[A-Za-z0-9_\-]{16,}"),
    re.compile(r"\bsk-[A-Za-z0-9]{16,}"),
    # Anthropic API key (`sk-ant-<acct-type><nn>-<body>`). Its hyphens break
    # the bare `sk-<alnum>` run above, so it needs its own rule; the body
    # admits URL-safe `_`/`-` and runs unbounded so the whole key collapses.
    re.compile(r"\bsk-ant-[A-Za-z0-9_\-]{20,}"),
    # HuggingFace user access token (`hf_` + >=34 alnum body).
    re.compile(r"\bhf_[A-Za-z0-9]{34,}"),
    # AWS access key id (fixed-length AKIA + 16).
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    # Slack token family (bot/user/app/refresh/legacy).
    re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}"),
    # Slack incoming-webhook URL (RED-3): the full URL is the credential
    # (anyone holding it can post to the channel). Distinct from `xox*` above.
    re.compile(r"https://hooks\.slack\.com/services/T[A-Za-z0-9_]+/B[A-Za-z0-9_]+/[A-Za-z0-9_]+"),
    # Google API key (AIza + 35) and OAuth 2.0 access token (ya29.<...>).
    # Both run unbounded from the length floor so the whole token collapses.
    # The ya29 body admits `.` because these opaque tokens carry further dots.
    re.compile(r"\bAIza[A-Za-z0-9_\-]{35,}"),
    re.compile(r"\bya29\.[A-Za-z0-9._\-]{20,}"),
    # Stripe secret (sk_) and restricted (rk_) keys, test/live/prod. Unbounded
    # body so a longer key collapses whole.
    re.compile(r"\b(?:sk|rk)_(?:test|live|prod)_[A-Za-z0-9]{10,}"),
    # GitLab personal/project/group access token.
    re.compile(r"\bglpat-[A-Za-z0-9_\-]{20,}"),
    # npm automation/access token (>=36-char body, unbounded so a longer token
    # collapses whole).
    re.compile(r"\bnpm_[A-Za-z0-9]{36,}"),
    # PyPI upload token (the AgEIcHlwaS5vcmc macaroon header is base64 of
    # "pypi.org" and is a near-unique structural anchor).
    re.compile(r"\bpypi-AgEIcHlwaS5vcmc[A-Za-z0-9_\-]{16,}"),
    # JSON Web Token: two `ey...` base64url segments (header and payload both
    # begin `{"`, which encodes to `ey`) plus an optional signature. The header
    # floor stays high (a real header is >=17 chars) as the anchor against
    # false positives; the payload / signature floors are low so a compact JWT
    # (e.g. `{"sub":"1"}`) is still redacted. Bearer-prefixed JWTs are caught by
    # REDACTION_PREFIX_PATTERNS; this collapses a bare one (an id_token in a
    # JSON body, a flag the prefix list does not name).
    re.compile(r"\bey[A-Za-z0-9_\-]{17,}\.ey[A-Za-z0-9_\-]{8,}(?:\.[A-Za-z0-9_\-]{8,})?"),
)


# --- Redaction: interactive secret prompts (v12) ---

# The last line of a session's output looks like a prompt for a secret
# (`[sudo] password for bob:`, `Enter passphrase for key '...':`, `Password:`,
# `Verification code:`). The next input typed into that session is a secret with no
# keyword of its own, so key/value redaction cannot see it; the session layer uses
# this to withhold it from the audit record (see `SessionRegistry.awaiting_secret`).
SECRET_PROMPT_PATTERN = re.compile(
    r"(?i)(?:pass(?:word|phrase|code)|\bpin\b|secret|token|api[ _-]?key"
    r"|verification code|one-time|otp)[^\r\n]{0,80}[:?]\s*$"
)


# --- Redaction: URL-embedded credentials (structure-preserving) ---

# The password may itself contain `@` (unencoded, but common): consume up to the
# LAST `@` before the path, so `https://u:p@ss@host/x` leaves nothing of `p@ss`.
# The run stops at `/` and whitespace, so a later `@` in a path or query is untouched.
URL_CREDS_PATTERN = re.compile(r"://[^/\s:@]+:[^\s/]+@")

# A token used as the whole user-info (`https://TOKEN@host/...`, v16): no colon, so the
# pattern above does not apply. Limited to web schemes and a 12+ character run so that
# the usual `ssh://git@host` / `user@host` forms are left alone.
URL_TOKEN_USERINFO_PATTERN = re.compile(r"(?i)\b(https?|ftps?|wss?)://[^/\s:@]{12,}@")


# --- Redaction: MySQL-family compact -p<value> (gated by family CLI) ---

MYSQL_FAMILY_CLI_PATTERN = re.compile(r"\b(?:mysql\w*|mariadb\w*|mycli)\b", re.IGNORECASE)
MYSQL_COMPACT_PASSWORD_PATTERN = re.compile(r"(?<![A-Za-z0-9-])(-p)[^\s=\-;&|][^\s;&|]*")


# --- Policy: tier classification heuristics ---

# Command position (v12): where a shell would start running a program. A word that
# only *names* a command (`man reboot`, `git log --grep=reboot`, `echo 'reboot
# required'`, `journalctl -u shutdown.target`) is not in this position and must not
# classify as running it. Matches at the start of a line, after a separator or
# subshell opener, after a privilege / wrapper command with its flags and VAR=val
# words, or at the start of a `sh -c '...'` string; an absolute path to the binary
# is allowed. The gaps are bounded or character-class limited, so it stays linear.
_CMD = (
    r"(?:(?:^|[;&|(`\n]|\$\()[^\S\n]*(?:\w+=\S*\s+){0,6}"
    r"|\b(?:sudo|doas)\s+(?:-[ugCphrtUT]\s+\S+\s+|-\S+\s+|\w+=\S*\s+){0,6}"
    r"|\b(?:exec|xargs|nohup|time|command|env)\s+(?:-\S+\s+|\w+=\S*\s+){0,6}"
    # Wrappers that take arguments (v16) count only where they start a command: `echo
    # timeout 5 reboot` and `man nice -n 10 reboot` do not run `timeout` or `reboot`.
    r"|(?:^|[;&|(`\n]|\$\()[^\S\n]*(?:\w+=\S*\s+){0,6}(?:/[\w./-]*/)?"
    r"(?:nice|ionice|timeout|setsid|stdbuf|chrt|taskset)\s+"
    r"(?:-\S+\s+|\d[\w.:,-]*\s+|\w+=\S*\s+){0,6}"
    r"|\b(?:sh|bash|zsh|dash|ksh)\s+-\w*c\s+[\"']\s*"
    r")(?:/[\w./-]*/)?"
)

# Substrings that strongly imply an irreversible / high-blast action. Two groups:
# distinctive tokens matched anywhere, and command names matched only in command
# position (`_CMD`) because the same word is common as an argument or in text.
TIER3_PATTERN = re.compile(
    r"(?imx)(?:(?<![\w])("
    r"rm\s+-[rf]|rm\s+-[a-z]*f|"
    # Long-option `rm` (RED-7): `rm --recursive`, `rm --force`,
    # `rm --no-preserve-root`, and mixed forms (`rm -r --force`, `rm file
    # --force`) — the short-flag alternatives above require a single dash
    # immediately after `rm `, so a `--`-flag slipped past them and
    # under-classified a genuinely destructive command below Tier 3. The
    # intervening-token count is BOUNDED (`{0,16}?`, disjoint \S/\s): a real
    # rm has few flags before the destructive one, and an unbounded `*?` would
    # be O(n^2) on `rm rm rm …` (classify retries every `rm ` position) — a
    # ReDoS on the synchronous admission path.
    r"rm\s+(?:\S+\s+){0,16}?--(?:recursive|force|no-preserve-root)\b|"
    # Disk / filesystem destruction. The partitioners are destructive except when
    # listing (`fdisk -l`, `sgdisk -p`, `parted ... print`), which v11 over-classified.
    r"shred|mkfs|wipefs|blkdiscard|"
    r"[sc]?fdisk\b(?!\s+(?:-l|--list|-s)\b)|"
    r"sgdisk\b(?!\s+(?:-p|--print|-i|--info)\b)|"
    r"parted\b(?!\s+(?:-l|--list)\b)(?![^|;&\n]{0,64}\b(?:print|unit)\b)|"
    r"dd\s+[^|]{0,256}of=/dev/|"
    r">>?\s*/dev/(?:[sh]d|nvme|vd|xvd|mmcblk)|"
    r"tee\s+(?:-\w+\s+)*/dev/(?:[sh]d|nvme|vd|xvd|mmcblk)|"
    r"zpool\s+(?:destroy|labelclear)|zfs\s+destroy|lvremove|vgremove|pvremove|"
    r"mdadm\s+[^|;&\n]{0,64}--(?:stop|zero-superblock)|"
    r"cryptsetup\s+(?:luks)?(?:format|erase)|nvme\s+format|"
    r"hdparm\s+[^|;&\n]{0,64}--security-erase|"
    # Recursive delete by another name, and IaC teardown. Bounded gaps (linear).
    r"find\b[^|;&\n]{0,256}?\s-delete\b|find\b[^|;&\n]{0,256}?-exec\s+rm\b|"
    r"(?:terraform|tofu|pulumi)\s+destroy|"
    # Power / run level via systemctl, and a sysrq write.
    r"systemctl\s+(?:reboot|poweroff|halt|kexec)\b|>\s*/proc/sysrq-trigger|"
    r"drop\s+database|drop\s+table|truncate\s+table|"
    r"git\s+push\s+(?:\S+\s+){0,8}?(?:--force\b|-f\b|\+\S)|git\s+reset\s+--hard|"
    r"userdel|deluser|gpasswd|"
    r"iptables\s+-F|nft\s+flush|"
    # `ip link ... down` only as a state change: `ip link show | grep down` is a read.
    r"ip\s+link\s+set\s+\S+(?:\s+\S+){0,4}?\s+down\b|ip\s+link\s+del(?:ete)?\b|ifdown\b|"
    r":\s*\(\s*\)\s*\{|"
    # --- Windows / PowerShell 7 (ADR 0011, WIN-1) ---
    # Destructive pwsh cmdlets are distinctive CapCase-hyphenated tokens (low
    # false-positive risk). `Remove-Item` is Tier 3 only WITH a -Recurse/-Force
    # flag, mirroring POSIX `rm` needing `-[rf]` (a bare single-file delete is
    # not Tier 3). The intervening-token count is bounded ({0,16}?) like the
    # `rm` long-option rule, so classify stays linear on `Remove-Item
    # Remove-Item …`. (`rm -Recurse` is already caught by the POSIX `rm\s+-[rf]`
    # rule via case-insensitivity.)
    r"remove-item\b(?:\s+\S+){0,16}?\s+-(?:recurse|force)\b|"
    r"clear-disk|format-volume|initialize-disk|"
    r"stop-computer|restart-computer|"
    r"remove-service|remove-localuser|remove-localgroup|clear-eventlog|"
    # cmd.exe delete/format verbs still reachable from pwsh; require the
    # recursive/quiet slash-flag (or a drive letter for format) so a bare
    # `del file.txt` / `Format-Table` does not over-classify.
    r"(?:del|erase|rd|rmdir)\b(?:\s+\S+){0,8}?\s+/[sq]\b|"
    r"format(?:\s+/\S+){0,4}\s+[a-z]:|diskpart|vssadmin\s+delete\s+shadows|"
    r"bcdedit|cipher\s+/w|(?:reg|sc)(?:\.exe)?\s+delete|wevtutil\s+cl"
    r"))"
    # Command-position group (v12): the same words as arguments or text no longer match.
    r"|" + _CMD + r"(?:"
    r"(?:reboot|shutdown|halt|poweroff)(?![\w.-])|"
    r"(?:init|telinit)\s+[06]\b|"
    r"passwd\s+\S|"
    # Cache wipe (v16), in command position like the other command names.
    r"redis-cli\b[^|;&\n]{0,128}?\bflush(?:all|db)\b"
    r")"
)


# Global options (with arity) that may sit between a command and its verb (v16). A flag
# that takes a value is listed with that value so the value is never mistaken for the verb
# (`systemctl --user status stop`, `docker compose --profile logs up`); any other
# option-looking word is treated as a boolean flag.
def _opt(valued: str, boolean: str) -> str:
    """One option word: ``valued`` names consume their value; any other flag is boolean.

    The boolean branch refuses the valued names, so the regex cannot back off a valued
    flag into a boolean one and then read its value as the verb.
    """
    return (
        rf"(?:(?:{valued})(?:=\S+|\s+\S+)"
        rf"|(?!(?:{valued})(?![\w-]))--?(?:{boolean})(?:=\S+)?)"
    )


_SYSTEMCTL_OPT = _opt(
    r"-H|--host|-M|--machine|-t|--type|-p|--property|--state|--root|-n|--lines|-o|--output"
    r"|-s|--signal|--kill-whom|--kill-who|--job-mode|--timestamp",
    r"[\w.-]+",
)
_KUBECTL_OPT = _opt(
    r"-n|--namespace|--context|--cluster|--kubeconfig|--user|-s|--server|--as|--as-group"
    r"|--token|--request-timeout|--cache-dir|--certificate-authority|--client-certificate"
    r"|--client-key|--tls-server-name|-v|--v",
    r"[\w-]+",
)
_COMPOSE_OPT = _opt(
    r"-f|--file|-p|--project-name|--profile|--env-file|--project-directory|--ansi|--parallel"
    r"|--progress|-H|--host|-c|--context",
    r"[\w-]+",
)

# Destinations whose modification is persistence or a system change (v16): see the
# redirect and `tee` rules in TIER2_PATTERN. The leading run is bounded so a long
# token cannot make the scan quadratic; no literal spaces (the pattern is verbose).
_SENSITIVE_DEST = (
    r"[\"']?(?:"
    r"/(?:boot|usr|bin|sbin|lib|lib32|lib64|opt|srv|root|sys)/"
    r"|/var/(?:spool|lib|www)/"
    r"|[^\s\"';&|]{0,200}/\.ssh/"
    r"|(?:[^\s\"';&|]{0,200}/)?authorized_keys2?(?![\w.-])"
    r"|[^\s\"';&|]{0,200}/sudoers(?![\w-])"
    r"|(?:[^\s\"';&|]{0,200}/)?\.(?:bashrc|bash_profile|bash_login|profile|zshrc|zprofile)(?![\w.-])"
    r")"
)

# Substrings that imply a stateful, visible change.
TIER2_PATTERN = re.compile(
    r"(?imx)(?:(?<![\w])("
    # systemctl: any state-changing verb, with the global flags (`--user`, `--now`,
    # `-H host`) that may precede it (v16; previously only five verbs, no flags).
    r"systemctl\s+(?:" + _SYSTEMCTL_OPT + r"\s+){0,4}"
    r"(stop|restart|disable|mask|kill|start|enable|reload|reload-or-restart|try-restart"
    r"|try-reload-or-restart|unmask|isolate|daemon-reload|daemon-reexec|set-default"
    r"|edit|revert)(?![\w.-])|"
    r"service\s+\S+\s+(stop|restart|start|reload)\b|"
    r"apt(-get)?\s+(install|remove|purge|upgrade|dist-upgrade)|"
    r"yum\s+(install|remove)|dnf\s+(install|remove)|pip\s+install|npm\s+(install|i)\b|"
    # docker compose / docker-compose: the read-only subcommands (`ps`, `logs`, `config`,
    # ...) are exempt; `up`, `down`, `exec` and anything unknown stay Tier 2 (v16).
    r"docker\s+(run|rm|stop|kill|build)|"
    r"docker(?:\s+|-)compose\b(?!(?:\s+" + _COMPOSE_OPT + r"){0,6}\s+"
    r"(?:ps|ls|logs|config|images|top|port|version|events)(?![\w.:/-]))|"
    # kubectl: mutating verbs after any global flags (`-n prod`, `--context x`). The
    # verb must be a whole word, so `logs job/create-db` is not a `create` (v16).
    r"kubectl\s+(?:"
    + _KUBECTL_OPT
    + r"\s+){0,6}(?:apply|delete|scale|rollout|exec|drain|cordon|uncordon|taint"
    r"|patch|edit|replace|create|label|annotate|cp|run|expose|autoscale|debug)(?![\w.-])|"
    r"(?:docker|podman)\s+(?:system|volume|image|container|network)\s+(?:prune|rm)\b|"
    r"(?:terraform|tofu)\s+apply|pulumi\s+up|git\s+clean\s+-\w*f|setenforce\b|"
    # Remote content piped into an interpreter: unknowable, stateful at best.
    r"(?:curl|wget)\b[^|\n]{0,512}\|\s*(?:sudo\s+(?:-\S+\s+)*)?"
    r"(?:(?:ba|z|da|k)?sh|python[\d.]*|perl|ruby|node)\b|"
    r"(?:ba|z)?sh\s+<\(\s*(?:curl|wget)\b|"
    r"chown|chmod\s+-R|chmod\s+[0-7]{3,4}\s+/|"
    # `crontab -l` only lists (v16); installing, editing or removing a crontab is Tier 2.
    r"crontab\b(?!(?:\s+-u\s+\S+)?\s+-l\b)|ln\s+-s|mv\s+/|cp\s+-[a-z]*\s+/|sed\s+-i|tee\s+/etc/|"
    # Writes to persistence and system locations other than /etc (v16): a redirect or
    # `tee` into `~/.ssh/`, `authorized_keys`, a shell rc file, `sudoers`, or
    # /root, /boot, /usr, /bin, /sbin, /lib*, /opt, /srv, /sys, /var/{spool,lib,www}.
    r">>?\s*" + _SENSITIVE_DEST + r"|tee\s+(?:-\w+\s+)*" + _SENSITIVE_DEST + r"|"
    r"git\s+(push|commit|merge|rebase)|"
    r"ufw\s+(allow|deny|enable|disable)|"
    r"ssh-copy-id|>\s*/etc/|>>\s*/etc/|"
    # --- Windows / PowerShell 7 (ADR 0011, WIN-1) ---
    # Service control (pwsh cmdlets + sc/net verbs), package install, firewall
    # changes, registry writes, user/task creation, and execution-policy
    # changes — the Windows analogues of systemctl / apt / ufw / crontab above.
    # `sc delete` / `reg delete` are Tier 3 (checked first), so only the
    # non-destructive verbs land here.
    r"stop-service|start-service|restart-service|set-service|"
    r"(?:sc|net)(?:\.exe)?\s+(?:stop|start)\b|"
    r"install-module|install-package|uninstall-module|uninstall-package|"
    r"choco\s+(?:install|uninstall)|winget\s+(?:install|uninstall)|"
    r"(?:remove|disable|set|new)-netfirewallrule|netsh\s+advfirewall|"
    r"(?:reg|sc)(?:\.exe)?\s+(?:add|config)|new-localuser|"
    r"register-scheduledtask|unregister-scheduledtask|schtasks\s+/create|"
    r"set-executionpolicy"
    r"))"
    r"|" + _CMD + r"(?:kill\s+-(?:9|KILL|SIGKILL)\b|pkill\b|killall\b|truncate\s"
    # Account, firewall and cache changes by command name (v16). Command position only:
    # `man useradd` and `grep iptables log` name the command without running it.
    r"|(?:useradd|usermod|groupadd|groupmod|groupdel|adduser|addgroup|chpasswd|chage"
    r"|visudo|newusers)(?![\w.-])"
    r"|ip6?tables(?:-nft|-legacy)?\s+(?:(?:-t\s+\w+|-w\s*\d*|--wait)\s+){0,3}-[AIDRPXNZ]\b"
    r"|ip6?tables-restore(?![\w.-])"
    r"|nft\s+(?:add|delete|insert|replace|create|destroy)\b"
    r"|firewall-cmd\b[^|;&\n]{0,64}--(?:(?:add|remove|set|new|delete|change|load)-\S|reload\b"
    r"|complete-reload\b|runtime-to-permanent\b|panic-(?:on|off)\b|lockdown-(?:on|off)\b)"
    r"|redis-cli\b[^|;&\n]{0,128}?\b(?:shutdown|config\s+set|replicaof|slaveof|debug"
    r"|script\s+flush|acl\s+(?:setuser|deluser))\b)"
)

# Privilege escalation wrappers should not be treated as low-risk commands.
# `runas` covers both `runas /user:Administrator …` and PowerShell's
# `Start-Process … -Verb RunAs` (the `RunAs` verb token matches `\brunas\b`
# case-insensitively) — the Windows analogue of sudo/doas/pkexec (ADR 0011).
PRIV_ESC_PATTERN = re.compile(r"(?ix)\b(sudo|doas|pkexec|runas)\b")

# Shell line continuation (v16): `\<newline>` is deleted before the shell parses a line, so
# `rm \<newline>-rf /x` is `rm -rf /x` and `r\<newline>m` is `rm`. The classifier removes
# it first; the whitespace-based patterns would otherwise miss the flag.
# The scan is quote-aware: a single-quoted span (and a double-quoted span without a
# continuation) is kept as written, because inside single quotes the pair is literal text.
# An unbalanced quote simply is not a span, so the rest of the text is scanned as unquoted.
LINE_CONTINUATION_PATTERN = re.compile(r"""'[^']*'|"(?:\\.|[^"\\])*"|\\\r?\n|\\.""")

# A segment (up to the next `;`, `&`, `|`, newline, `(` or backtick) whose command only
# reads or prints text (v16): `grep sudo /var/log/auth.log`, `man sudo`, `echo sudo`. A
# privilege wrapper named there is data, not a command, so the privilege-escalation tier
# is not applied to it. Other segments of the same line still are.
#
# Not applied when the line can evaluate text (an interpreter or `xargs` after a pipe,
# `eval`/`source`/`exec`, a `sh -c` string, a backtick, `$(` or `<(`): `echo 'sudo ...' | sh`
# runs what the reader printed, so the wrapper there is a command, not data.
PRIV_ESC_EVAL_HINT = re.compile(
    r"(?i)\|\s*(?:\S*/)?(?:sudo\s+)?(?:(?:ba|z|da|k)?sh|python[\d.]*|perl|ruby|node|php|xargs"
    r"|source|eval)(?![\w.-])|(?<![\w-])(?:eval|source|exec)(?![\w-])|[`]|\$\(|<\(|(?<![\w-])(?:ba|z|da|k)?sh\s+-\w*c(?![\w-])"
)

PRIV_ESC_READER_SEGMENT = re.compile(
    r"(?im)(?:^|[;&|(`])[^\S\n]*(?:grep|egrep|fgrep|zgrep|rg|ag|man|which|whereis|type|apropos"
    r"|echo|printf|journalctl|locate)\b[^;&|\n(`]*"
)
